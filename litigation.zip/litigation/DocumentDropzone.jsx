import { useCallback, useState, useEffect } from 'react';
import { useDropzone } from 'react-dropzone';
import { Spinner } from 'react-bootstrap';
import Swal from 'sweetalert2';
import { Icon } from '@iconify/react';
import {
  ALLOWED_MIME_TYPES,
  MAX_FILE_SIZE,
  ALLOWED_FILE_TYPES,
  FILE_ICON_MAP,
  DEFAULT_FILE_ICON,
} from './constants';
import { getDocumentDownloadUrl, getDocumentViewUrl, deleteDocument, fetchDocumentBlob } from './api';
import api from '../../api/axios';

function formatSize(bytes) {
  if (!bytes) return '0 B';
  if (bytes >= 1048576) return (bytes / 1048576).toFixed(1) + ' MB';
  if (bytes >= 1024) return Math.round(bytes / 1024) + ' KB';
  return bytes + ' B';
}

function getFileIcon(mimeType) {
  return FILE_ICON_MAP[mimeType] || DEFAULT_FILE_ICON;
}

// ── Auth-aware document link ────────────────────────────────────────
function AuthDocLink({ caseId, doc }) {
  const [loading, setLoading] = useState(false);

  async function handlePreview(e) {
    e.preventDefault();
    setLoading(true);
    try {
      const blob = await fetchDocumentBlob(caseId, doc.id);
      const url = URL.createObjectURL(blob);
      window.open(url, '_blank');
    } catch (err) {
      Swal.fire({ icon: 'error', title: 'Could not open document', text: err.message || 'Preview failed' });
    } finally {
      setLoading(false);
    }
  }

  async function handleDownload(e) {
    e.preventDefault();
    setLoading(true);
    try {
      const blob = await fetchDocumentBlob(caseId, doc.id);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = doc.file_name || 'document';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      Swal.fire({ icon: 'error', title: 'Could not download document', text: err.message || 'Download failed' });
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="d-flex gap-1">
      <button
        type="button"
        className="btn btn-sm btn-soft-primary"
        title="Preview"
        onClick={handlePreview}
        disabled={loading}
      >
        {loading ? <Spinner animation="border" size="sm" /> : <Icon icon="mdi:eye-outline" width={16} />}
      </button>
      <button
        type="button"
        className="btn btn-sm btn-soft-primary"
        title="Download"
        onClick={handleDownload}
        disabled={loading}
      >
        <Icon icon="mdi:download-outline" width={16} />
      </button>
    </div>
  );
}

export default function DocumentDropzone({ caseId, existingDocs = [], onFilesChange, newFiles = [] }) {
  const [docs, setDocs] = useState(existingDocs);
  const [pendingFiles, setPendingFiles] = useState([]);

  useEffect(() => {
    setDocs(existingDocs);
  }, [existingDocs]);

  // Sync pending files to parent
  useEffect(() => {
    if (onFilesChange) {
      onFilesChange(pendingFiles);
    }
  }, [pendingFiles, onFilesChange]);

  const onDrop = useCallback((acceptedFiles) => {
    const validFiles = acceptedFiles.filter((f) => {
      if (f.size > MAX_FILE_SIZE) {
        alert(`File "${f.name}" exceeds 10 MB limit.`);
        return false;
      }
      return true;
    });
    setPendingFiles((prev) => [...prev, ...validFiles]);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: ALLOWED_MIME_TYPES.reduce((acc, mime) => ({ ...acc, [mime]: [] }), {}),
    maxSize: MAX_FILE_SIZE,
  });

  function removePending(index) {
    setPendingFiles((prev) => prev.filter((_, i) => i !== index));
  }

  async function handleDeleteDoc(doc) {
    if (!window.confirm(`Delete "${doc.file_name}"?`)) return;
    try {
      await deleteDocument(caseId, doc.id);
      setDocs((prev) => prev.filter((d) => d.id !== doc.id));
    } catch (err) {
      alert(err.response?.data?.message || 'Failed to delete document');
    }
  }

  return (
    <div>
      {/* Existing Documents */}
      {docs.length > 0 && (
        <div className="mb-3">
          <label className="form-label fw-semibold">Uploaded Documents</label>
          <div className="list-group list-group-flush">
            {docs.map((doc) => {
              const icon = getFileIcon(doc.file_type);
              return (
                <div key={doc.id} className="list-group-item d-flex align-items-center gap-3 px-3 py-2 bg-body">
                  <i className={`fas ${icon.icon}`} style={{ color: icon.color }}></i>
                  <div className="flex-grow-1 min-width-0">
                    <div className="text-truncate fw-medium fs-sm">{doc.file_name}</div>
                    <small className="text-muted">{doc.file_size_formatted}</small>
                  </div>
                  {caseId && <AuthDocLink caseId={caseId} doc={doc} />}
                  <button
                    type="button"
                    className="btn btn-sm btn-soft-primary text-danger"
                    title="Delete"
                    onClick={() => handleDeleteDoc(doc)}
                  >
                    <Icon icon="mdi:trash-outline" width={16} />
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Dropzone */}
      <div
        {...getRootProps()}
        className={`border-2 border-dashed rounded-3 p-4 text-center cursor-pointer transition ${
          isDragActive ? 'border-primary bg-primary bg-opacity-10' : 'border-secondary'
        }`}
        style={{ borderStyle: 'dashed', borderWidth: '2px', cursor: 'pointer' }}
      >
        <input {...getInputProps()} />
        <Icon icon="mdi:cloud-upload-outline" width={26} className="text-muted mb-2" />
        <p className="mb-1 fw-medium">Click to browse or drag & drop files here</p>
        <small className="text-muted">PDF, JPG, JPEG, PNG, DOC, DOCX &middot; Max 10 MB each</small>
      </div>

      {/* Pending Files */}
      {pendingFiles.length > 0 && (
        <div className="mt-3">
          <label className="form-label fw-semibold">Pending Upload ({pendingFiles.length})</label>
          <div className="list-group list-group-flush">
            {pendingFiles.map((file, idx) => {
              const icon = getFileIcon(file.type);
              return (
                <div key={idx} className="list-group-item d-flex align-items-center gap-3 px-3 py-2 bg-body">
                  <i className={`fas ${icon.icon}`} style={{ color: icon.color }}></i>
                  <div className="flex-grow-1 min-width-0">
                    <div className="text-truncate fw-medium fs-sm">{file.name}</div>
                    <small className="text-muted">{formatSize(file.size)}</small>
                  </div>
                  <button
                    type="button"
                    className="btn btn-sm btn-soft-primary text-danger"
                    title="Remove"
                    onClick={() => removePending(idx)}
                  >
                    <Icon icon="mdi:close" width={16} />
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

