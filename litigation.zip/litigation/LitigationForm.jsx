import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { yupResolver } from '@hookform/resolvers/yup';
import * as yup from 'yup';
import { Modal, Button, Form, Alert, Spinner } from 'react-bootstrap';
import Swal from 'sweetalert2';
import DatePickerField from '../../components/DatePickerField';
import SearchableSelect from '../../components/SearchableSelect';
import { fetchCase, createCase, updateCase, fetchCompanies } from './api';
import {
  CASE_TYPE_OPTIONS,
  STAGE_OPTIONS,
  STATUS_OPTIONS,
} from './constants';
import DocumentDropzone from './DocumentDropzone';

const STEPS = [
  { key: 'basic', label: 'Basic Info', icon: 'ti-info-circle' },
  { key: 'advocates', label: 'Advocates', icon: 'ti-users' },
  { key: 'status', label: 'Case Status', icon: 'ti-gavel' },
  { key: 'fee', label: 'Fee', icon: 'ti-currency-rupee' },
  { key: 'documents', label: 'Documents', icon: 'ti-file-text' },
];

function toDateInputValue(value) {
  if (!value) return '';
  const str = String(value);
  if (/^\d{4}-\d{2}-\d{2}/.test(str)) return str.slice(0, 10);
  const d = new Date(str);
  if (isNaN(d.getTime())) return '';
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

const litigationSchema = yup.object({
  company_id: yup.string().nullable(),
  case_representative: yup.string().nullable(),
  court_name: yup.string().required('Court name is required'),
  jurisdiction: yup.string().nullable(),
  location: yup.string().nullable(),
  petitioner: yup.string().required('Petitioner is required'),
  respondent: yup.string().required('Respondent is required'),
  litigation_number: yup.string().required('Litigation number is required'),
  cnr_number: yup.string().nullable(),
  case_type: yup.string().required('Case type is required'),
  subject: yup.string().nullable(),
  facts: yup.string().nullable(),
  petitioner_advocate_name: yup.string().nullable(),
  petitioner_advocate_contact: yup.string().nullable(),
  petitioner_advocate_email: yup.string().nullable(),
  petitioner_advocate_address: yup.string().nullable(),
  respondent_advocate_name: yup.string().nullable(),
  respondent_advocate_contact: yup.string().nullable(),
  respondent_advocate_email: yup.string().nullable(),
  respondent_advocate_address: yup.string().nullable(),
  stage: yup.string().required('Stage is required'),
  next_hearing_date: yup.string().nullable(),
  status: yup.string().required('Status is required'),
  advocate_fee: yup.number().typeError('Must be a number').min(0, 'Min 0').nullable(),
  paid_amount: yup.number().typeError('Must be a number').min(0, 'Min 0').nullable(),
  remarks: yup.string().nullable(),
});

const formDefaults = {
  company_id: '',
  case_representative: '',
  court_name: '',
  jurisdiction: '',
  location: '',
  petitioner: '',
  respondent: '',
  litigation_number: '',
  cnr_number: '',
  case_type: '',
  subject: '',
  facts: '',
  petitioner_advocate_name: '',
  petitioner_advocate_contact: '',
  petitioner_advocate_email: '',
  petitioner_advocate_address: '',
  respondent_advocate_name: '',
  respondent_advocate_contact: '',
  respondent_advocate_email: '',
  respondent_advocate_address: '',
  stage: 'filing',
  next_hearing_date: '',
  status: 'active',
  advocate_fee: '',
  paid_amount: '',
  remarks: '',
};

const STEP_FIELDS = {
  basic: ['court_name', 'petitioner', 'respondent', 'litigation_number', 'case_type', 'company_id', 'case_representative', 'cnr_number', 'jurisdiction', 'location', 'subject', 'facts'],
  advocates: ['petitioner_advocate_name', 'petitioner_advocate_contact', 'petitioner_advocate_email', 'petitioner_advocate_address', 'respondent_advocate_name', 'respondent_advocate_contact', 'respondent_advocate_email', 'respondent_advocate_address'],
  status: ['stage', 'status', 'next_hearing_date', 'remarks'],
  fee: ['advocate_fee', 'paid_amount'],
  documents: [],
};

export default function LitigationForm({ show, onHide, onSuccess, id }) {
  const isEdit = Boolean(id);
  const [step, setStep] = useState(0);
  const [loading, setLoading] = useState(isEdit);
  const [companies, setCompanies] = useState([]);
  const [existingDocs, setExistingDocs] = useState([]);
  const [newFiles, setNewFiles] = useState([]);
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  const {
    register,
    handleSubmit,
    reset,
    watch,
    setValue,
    trigger,
    formState: { errors, isSubmitting },
  } = useForm({
    resolver: yupResolver(litigationSchema),
    defaultValues: formDefaults,
    mode: 'onChange',
  });

  const advocateFee = parseFloat(watch('advocate_fee')) || 0;
  const paidAmount = parseFloat(watch('paid_amount')) || 0;
  const isOverpaid = advocateFee > 0 && paidAmount > advocateFee;
  const balance = isOverpaid ? paidAmount - advocateFee : Math.max(0, advocateFee - paidAmount);

  useEffect(() => {
    const sub = watch(() => setError(''));
    return () => sub.unsubscribe();
  });

  useEffect(() => {
    fetchCompanies()
      .then(setCompanies)
      .catch(() => {});
  }, []);

  useEffect(() => {
    if (!show) return;
    setStep(0);
    setError('');
    reset(formDefaults);
    setExistingDocs([]);
    setNewFiles([]);
    setLoading(isEdit);

    if (!isEdit) return;
    fetchCase(id)
      .then((caseData) => {
        const formData = { ...formDefaults };
        Object.keys(formDefaults).forEach((key) => {
          if (caseData[key] !== undefined && caseData[key] !== null) {
            formData[key] = caseData[key];
          }
        });
        formData.company_id = caseData.company_id ? String(caseData.company_id) : '';
        formData.next_hearing_date = toDateInputValue(caseData.next_hearing_date);
        reset(formData);
        setExistingDocs(caseData.documents || []);
        setLoading(false);
      })
      .catch(() => {
        Swal.fire({ icon: 'error', title: 'Could not load case', confirmButtonColor: '#236dc9' });
        onHide();
      });
  }, [show, id, isEdit, reset, onHide]);

  function validateStep(i) {
    const fields = STEP_FIELDS[STEPS[i].key];
    if (!fields || fields.length === 0) return '';
    for (const field of fields) {
      if (errors[field]) return errors[field].message;
    }
    return '';
  }

  async function goNext() {
    const fields = STEP_FIELDS[STEPS[step].key];
    const valid = fields.length > 0 ? await trigger(fields) : true;
    if (!valid) { setError('Please fill all required fields before proceeding.'); return; }
    if (isOverpaid) { setError('Paid amount cannot exceed advocate fee'); return; }
    setError('');
    setStep((s) => Math.min(STEPS.length - 1, s + 1));
  }

  function goBack() { setError(''); setStep((s) => Math.max(0, s - 1)); }

  async function handleStepClick(targetIndex) {
    if (targetIndex === step) return;
    if (targetIndex < step) { setError(''); setStep(targetIndex); return; }
    for (let i = step; i < targetIndex; i++) {
      const fields = STEP_FIELDS[STEPS[i].key];
      if (fields.length > 0) {
        const valid = await trigger(fields);
        if (!valid) { setError(`Please fill all required fields in "${STEPS[i].label}" before proceeding.`); return; }
      }
    }
    setError('');
    setStep(targetIndex);
  }

  async function onSubmitTab() {
    if (isOverpaid) { setError('Paid amount cannot exceed advocate fee'); return; }
    const msg = validateStep(step);
    if (msg) { setError(msg); return; }

    setSaving(true);
    setError('');
    try {
      const values = watch();
      const formData = new FormData();
      Object.entries(values).forEach(([key, value]) => {
        if (value !== null && value !== undefined && value !== '') {
          formData.append(key, value);
        }
      });
      newFiles.forEach((file) => { formData.append('documents', file); });
      await updateCase(id, formData);
      Swal.fire({ icon: 'success', title: 'Updated', timer: 1200, showConfirmButton: false });
      onHide();
      if (onSuccess) onSuccess();
    } catch (err) {
      const response = err.response;
      if (response?.status === 422 && response.data?.errors) {
        const firstError = Object.keys(response.data.errors)[0];
        Swal.fire({ icon: 'error', title: 'Validation Error', text: response.data.errors[firstError]?.[0] || 'Please check the form.', confirmButtonColor: '#236dc9' });
      } else {
        Swal.fire({ icon: 'error', title: 'Save failed', text: response?.data?.message || 'Please try again.', confirmButtonColor: '#236dc9' });
      }
    } finally {
      setSaving(false);
    }
  }

  async function onSubmit(values) {
    if (isOverpaid) { setError('Paid amount cannot exceed advocate fee'); return; }
    for (let i = 0; i < STEPS.length; i++) {
      const msg = validateStep(i);
      if (msg) { setError(msg); setStep(i); return; }
    }

    setSaving(true);
    setError('');
    try {
      const formData = new FormData();
      Object.entries(values).forEach(([key, value]) => {
        if (value !== null && value !== undefined && value !== '') {
          formData.append(key, value);
        }
      });
      newFiles.forEach((file) => { formData.append('documents', file); });

      if (isEdit) {
        await updateCase(id, formData);
        Swal.fire({ icon: 'success', title: 'Case updated', timer: 1200, showConfirmButton: false });
        onHide();
        if (onSuccess) onSuccess();
      } else {
        await createCase(formData);
        Swal.fire({ icon: 'success', title: 'Case created', timer: 1200, showConfirmButton: false });
        onHide();
        if (onSuccess) onSuccess();
      }
    } catch (err) {
      const response = err.response;
      if (response?.status === 422 && response.data?.errors) {
        const firstError = Object.keys(response.data.errors)[0];
        Swal.fire({
          icon: 'error', title: 'Validation Error',
          text: response.data.errors[firstError]?.[0] || 'Please check the form and try again.',
          confirmButtonColor: '#236dc9',
        });
      } else {
        Swal.fire({
          icon: 'error', title: 'Save failed',
          text: response?.data?.message || 'Please check the form and try again.',
          confirmButtonColor: '#236dc9',
        });
      }
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal show={show} onHide={onHide} size="xl" fullscreen="md-down" centered backdrop="static" enforceFocus={false} className="lfm-modal" dialogClassName="lfm-modal">
      <style>{`
        .lfm-modal .form-label, .lfm-modal label { font-family: "DM Sans", sans-serif !important; }
        .lfm-steps-wrap { overflow-x: auto; overflow-y: hidden; flex-shrink: 0; }
        .lfm-header { flex-shrink: 0; }
        .lfm-modal .modal-body { min-height: 340px; }
        .lfm-modal .modal-footer {
          flex-shrink: 0; position: sticky; bottom: 0; z-index: 5;
          background: var(--theme-secondary-bg);
        }
        .lfm-header-icon {
          width: 44px; height: 44px; border-radius: 12px; flex-shrink: 0;
          display: flex; align-items: center; justify-content: center;
          font-size: 20px; color: #fff;
        }
        .lfm-stepper { gap: 0; }
        .lfm-stepper-item-wrap { display: flex; align-items: flex-start; flex: 0 0 auto; }
        .lfm-stepper-item {
          display: flex; flex-direction: column; align-items: center; cursor: pointer;
          flex-shrink: 0; min-width: 76px; transition: transform 0.15s ease;
        }
        .lfm-stepper-item:hover { transform: translateY(-1px); }
        .lfm-stepper-item:hover .lfm-stepper-circle:not(.active):not(.done) {
          border-color: #236dc9; color: #236dc9;
        }
        .lfm-stepper-circle {
          width: 28px; height: 28px; border-radius: 50%; flex-shrink: 0;
          display: flex; align-items: center; justify-content: center;
          font-size: 0.75rem;
          border: 2px solid var(--theme-border-color);
          color: var(--theme-emphasis-color);
          background: var(--theme-secondary-bg);
          transition: all 0.2s ease;
        }
        .lfm-stepper-circle.active {
          border-color: #236dc9;
          background: linear-gradient(135deg, #236dc9, #1e5dab);
          color: #fff;
          box-shadow: 0 0 0 4px rgba(35, 109, 201, 0.15), 0 3px 8px rgba(35, 109, 201, 0.3);
          transform: scale(1.08);
        }
        .lfm-stepper-circle.done {
          border-color: #159440;
          background: linear-gradient(90deg, #159440, #0f7a35);
          color: #fff;
          box-shadow: 0 2px 6px rgba(21, 148, 64, 0.25);
        }
        .lfm-stepper-label {
          font-size: 0.72rem; font-weight: 650; margin-top: 5px;
          color: var(--theme-emphasis-color); white-space: nowrap;
          transition: color 0.2s ease;
        }
        .lfm-stepper-label.active { color: #236dc9; font-weight: 750; }
        .lfm-stepper-line {
          flex: 1 1 auto; height: 3px; border-radius: 2px;
          background: var(--theme-border-color); margin-top: 16px; min-width: 24px;
          transition: background 0.3s ease;
        }
        .lfm-stepper-line.done { background: linear-gradient(90deg, #159440, #0f7a35); }
        .lfm-advocate-card {
          border: 1px solid var(--theme-border-color, rgba(15,23,42,0.06));
          border-radius: 10px;
          padding: 16px;
        }
        .lfm-advocate-title {
          font-size: 0.85rem; font-weight: 700; color: var(--theme-body-color);
          margin: 0 0 12px;
          padding-bottom: 8px;
          border-bottom: 2px solid var(--bs-primary);
          display: inline-block;
        }
      `}</style>

      <Modal.Header closeButton className="lfm-header">
        <div className="d-flex align-items-center gap-3">
          <div className="lfm-header-icon bg-warning">
            <i className={`ti ${isEdit ? 'ti-pencil' : 'ti-plus'}`} />
          </div>
          <div>
            <Modal.Title className="fs-lg fw-bold mb-0 d-flex align-items-center gap-2">
              {isEdit ? 'Edit Litigation Case' : 'Add Litigation Case'}
            </Modal.Title>
            <div className="fs-xs text-muted">
              {isEdit ? 'Update the details below and save changes' : 'Fill in the details to create a new case'}
            </div>
          </div>
        </div>
      </Modal.Header>

      <div className="lfm-steps-wrap px-3 pt-3 pb-2 border-bottom">
        <div className="lfm-stepper d-flex align-items-start">
          {STEPS.map((s, i) => (
            <div className="lfm-stepper-item-wrap" key={s.key}>
              <div className="lfm-stepper-item" role="button" onClick={() => handleStepClick(i)}>
                <div className={`lfm-stepper-circle ${i === step ? 'active' : i < step ? 'done' : ''}`}>
                  {i < step ? <i className="ti ti-check" /> : <i className={`ti ${s.icon}`} />}
                </div>
                <div className={`lfm-stepper-label ${i === step ? 'active' : ''}`}>{s.label}</div>
              </div>
              {i < STEPS.length - 1 && <div className={`lfm-stepper-line ${i < step ? 'done' : ''}`} />}
            </div>
          ))}
        </div>
      </div>

      <Modal.Body>
        {error && <Alert variant="danger" className="py-2">{error}</Alert>}
        {isEdit && loading ? (
          <div className="text-center py-5"><Spinner animation="border" size="sm" /></div>
        ) : (
          <>
            {step === 0 && (
              <div className="row g-3">
                <div className="col-md-4">
                  <Form.Group>
                    <Form.Label>Company</Form.Label>
                    <SearchableSelect
                      options={companies.map((c) => ({ id: c.id, label: `${c.company_name} (${c.company_code})` }))}
                      value={watch('company_id')}
                      onChange={(opt) => setValue('company_id', opt.id)}
                      placeholder="Select company"
                    />
                  </Form.Group>
                </div>
                <div className="col-md-4">
                  <Form.Group>
                    <Form.Label>Case Representative</Form.Label>
                    <Form.Control placeholder="Representative name" {...register('case_representative')} />
                  </Form.Group>
                </div>
                <div className="col-md-4">
                  <Form.Group>
                    <Form.Label>Litigation Number <span className="text-danger">*</span></Form.Label>
                    <Form.Control placeholder="e.g. CS/123/2025" className={errors.litigation_number ? 'is-invalid' : ''} {...register('litigation_number')} />
                    {errors.litigation_number && <div className="invalid-feedback">{errors.litigation_number.message}</div>}
                  </Form.Group>
                </div>
                <div className="col-md-4">
                  <Form.Group>
                    <Form.Label>CNR Number</Form.Label>
                    <Form.Control placeholder="e.g. TNCH01-000001-2025" {...register('cnr_number')} />
                  </Form.Group>
                </div>
                <div className="col-md-4">
                  <Form.Group>
                    <Form.Label>Court Name <span className="text-danger">*</span></Form.Label>
                    <Form.Control placeholder="e.g. High Court of Madras" className={errors.court_name ? 'is-invalid' : ''} {...register('court_name')} />
                    {errors.court_name && <div className="invalid-feedback">{errors.court_name.message}</div>}
                  </Form.Group>
                </div>
                <div className="col-md-4">
                  <Form.Group>
                    <Form.Label>Jurisdiction</Form.Label>
                    <Form.Control placeholder="e.g. Civil, Criminal" {...register('jurisdiction')} />
                  </Form.Group>
                </div>
                <div className="col-md-4">
                  <Form.Group>
                    <Form.Label>Location</Form.Label>
                    <Form.Control placeholder="e.g. Chennai" {...register('location')} />
                  </Form.Group>
                </div>
                <div className="col-md-4">
                  <Form.Group>
                    <Form.Label>Petitioner / Plaintiff <span className="text-danger">*</span></Form.Label>
                    <Form.Control placeholder="Petitioner name" className={errors.petitioner ? 'is-invalid' : ''} {...register('petitioner')} />
                    {errors.petitioner && <div className="invalid-feedback">{errors.petitioner.message}</div>}
                  </Form.Group>
                </div>
                <div className="col-md-4">
                  <Form.Group>
                    <Form.Label>Respondent / Defendant <span className="text-danger">*</span></Form.Label>
                    <Form.Control placeholder="Respondent name" className={errors.respondent ? 'is-invalid' : ''} {...register('respondent')} />
                    {errors.respondent && <div className="invalid-feedback">{errors.respondent.message}</div>}
                  </Form.Group>
                </div>
                <div className="col-md-4">
                  <Form.Group>
                    <Form.Label>Case Type <span className="text-danger">*</span></Form.Label>
                    <SearchableSelect
                      options={CASE_TYPE_OPTIONS.map((o) => ({ id: o.value, label: o.label }))}
                      value={watch('case_type')}
                      onChange={(opt) => setValue('case_type', opt.id)}
                      placeholder="Select case type"
                    />
                    {errors.case_type && <div className="text-danger mt-1" style={{ fontSize: '0.75rem' }}>{errors.case_type.message}</div>}
                  </Form.Group>
                </div>
                <div className="col-md-6">
                  <Form.Group>
                    <Form.Label>Subject</Form.Label>
                    <Form.Control placeholder="Brief case subject" {...register('subject')} />
                  </Form.Group>
                </div>
                <div className="col-12">
                  <Form.Group>
                    <Form.Label>Facts</Form.Label>
                    <Form.Control as="textarea" rows={3} placeholder="Detailed case facts..." {...register('facts')} />
                  </Form.Group>
                </div>
              </div>
            )}

            {step === 1 && (
              <div className="row g-3">
                <div className="col-md-6">
                  <div className="lfm-advocate-card">
                    <div className="lfm-advocate-title">Petitioner Advocate</div>
                    <div className="row g-3">
                      <div className="col-12">
                        <Form.Group><Form.Label>Name</Form.Label><Form.Control placeholder="Advocate full name" {...register('petitioner_advocate_name')} /></Form.Group>
                      </div>
                      <div className="col-12">
                        <Form.Group>
                          <Form.Label>Contact</Form.Label>
                          <div className="input-group">
                            <span className="input-group-text">+91</span>
                            <Form.Control placeholder="9876543210" {...register('petitioner_advocate_contact')} />
                          </div>
                        </Form.Group>
                      </div>
                      <div className="col-12">
                        <Form.Group><Form.Label>Email</Form.Label><Form.Control type="email" placeholder="advocate@lawfirm.com" {...register('petitioner_advocate_email')} /></Form.Group>
                      </div>
                      <div className="col-12">
                        <Form.Group><Form.Label>Address</Form.Label><Form.Control as="textarea" rows={2} placeholder="Office address" {...register('petitioner_advocate_address')} /></Form.Group>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-md-6">
                  <div className="lfm-advocate-card">
                    <div className="lfm-advocate-title">Respondent Advocate</div>
                    <div className="row g-3">
                      <div className="col-12">
                        <Form.Group><Form.Label>Name</Form.Label><Form.Control placeholder="Advocate full name" {...register('respondent_advocate_name')} /></Form.Group>
                      </div>
                      <div className="col-12">
                        <Form.Group>
                          <Form.Label>Contact</Form.Label>
                          <div className="input-group">
                            <span className="input-group-text">+91</span>
                            <Form.Control placeholder="9876543210" {...register('respondent_advocate_contact')} />
                          </div>
                        </Form.Group>
                      </div>
                      <div className="col-12">
                        <Form.Group><Form.Label>Email</Form.Label><Form.Control type="email" placeholder="advocate@lawfirm.com" {...register('respondent_advocate_email')} /></Form.Group>
                      </div>
                      <div className="col-12">
                        <Form.Group><Form.Label>Address</Form.Label><Form.Control as="textarea" rows={2} placeholder="Office address" {...register('respondent_advocate_address')} /></Form.Group>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="row g-3">
                <div className="col-md-3">
                  <Form.Group>
                    <Form.Label>Stage <span className="text-danger">*</span></Form.Label>
                    <SearchableSelect
                      options={STAGE_OPTIONS.map((o) => ({ id: o.value, label: o.label }))}
                      value={watch('stage')}
                      onChange={(opt) => setValue('stage', opt.id)}
                      placeholder="Select stage"
                    />
                    {errors.stage && <div className="text-danger mt-1" style={{ fontSize: '0.75rem' }}>{errors.stage.message}</div>}
                  </Form.Group>
                </div>
                <div className="col-md-3">
                  <Form.Group>
                    <Form.Label>Next Hearing Date</Form.Label>
                    <DatePickerField value={watch('next_hearing_date')} onChange={(v) => setValue('next_hearing_date', v)} />
                  </Form.Group>
                </div>
                <div className="col-md-3">
                  <Form.Group>
                    <Form.Label>Status <span className="text-danger">*</span></Form.Label>
                    <SearchableSelect
                      options={STATUS_OPTIONS.map((o) => ({ id: o.value, label: o.label }))}
                      value={watch('status')}
                      onChange={(opt) => setValue('status', opt.id)}
                      placeholder="Select status"
                    />
                    {errors.status && <div className="text-danger mt-1" style={{ fontSize: '0.75rem' }}>{errors.status.message}</div>}
                  </Form.Group>
                </div>
                <div className="col-12">
                  <Form.Group>
                    <Form.Label>Remarks</Form.Label>
                    <Form.Control as="textarea" rows={2} placeholder="Any additional remarks..." {...register('remarks')} />
                  </Form.Group>
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="row g-3">
                <div className="col-md-4">
                  <Form.Group>
                    <Form.Label>Advocate Fee (₹)</Form.Label>
                    <Form.Control type="number" min="0" step="0.01" placeholder="0.00" {...register('advocate_fee')} />
                    <Form.Text>Total agreed fee</Form.Text>
                  </Form.Group>
                </div>
                <div className="col-md-4">
                  <Form.Group>
                    <Form.Label>Paid Amount (₹)</Form.Label>
                    <Form.Control
                      type="number" min="0" step="0.01" placeholder="0.00"
                      className={isOverpaid ? 'is-invalid border-danger' : ''}
                      {...register('paid_amount')}
                    />
                    {!isOverpaid && <Form.Text>Amount paid so far</Form.Text>}
                    {isOverpaid && (
                      <div className="text-danger mt-1" style={{ fontSize: '0.72rem', fontWeight: 600 }}>
                        <i className="ti ti-alert-circle me-1" />
                        Exceeds advocate fee by ₹{(paidAmount - advocateFee).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                      </div>
                    )}
                  </Form.Group>
                </div>
                <div className="col-md-4">
                  <Form.Group>
                    <Form.Label>{isOverpaid ? 'Overpaid By' : 'Balance'}</Form.Label>
                    <div className="input-group">
                      <span className="input-group-text">₹</span>
                      <Form.Control
                        className={`bg-body-secondary fw-semibold ${isOverpaid ? 'text-danger' : balance > 0 ? 'text-warning' : 'text-success'}`}
                        value={balance.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                        readOnly
                      />
                      <span className="input-group-text bg-body-secondary">
                        <span className={`badge fs-10 ${isOverpaid ? 'bg-danger' : 'bg-info'}`}>Auto</span>
                      </span>
                    </div>
                  </Form.Group>
                </div>
              </div>
            )}

            {step === 4 && (
              <div className="row g-3">
                <div className="col-12">
                  <DocumentDropzone
                    caseId={id}
                    existingDocs={existingDocs}
                    newFiles={newFiles}
                    onFilesChange={setNewFiles}
                  />
                </div>
              </div>
            )}
          </>
        )}
      </Modal.Body>

      <Modal.Footer className="d-flex align-items-center justify-content-between">
        <div className="d-flex gap-2">
          {step > 0 && !isEdit && <Button variant="outline-secondary" onClick={goBack}><i className="ti ti-arrow-left me-1" /> Back</Button>}
        </div>
        <div className="d-flex gap-2">
          <Button variant="light" onClick={onHide}>Cancel</Button>
          {isEdit ? (
            <Button onClick={onSubmitTab} disabled={saving || loading}>
              {saving ? 'Saving...' : 'Update'}
            </Button>
          ) : (
            <>
              {step < STEPS.length - 1 && <Button variant="primary" onClick={goNext} disabled={isOverpaid}>Next <i className="ti ti-arrow-right ms-1" /></Button>}
              {step === STEPS.length - 1 && (
                <Button onClick={handleSubmit(onSubmit)} disabled={saving}>
                  {saving ? 'Saving...' : 'Save Case'}
                </Button>
              )}
            </>
          )}
        </div>
      </Modal.Footer>
    </Modal>
  );
}
