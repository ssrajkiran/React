import { useEffect, useState, useCallback, useRef, useMemo } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { Spinner, Alert, Badge } from 'react-bootstrap';
import Swal from 'sweetalert2';
import Breadcrumb from '../../components/Breadcrumb';
import TableColumnsControl from '../../components/TableColumnsControl';
import SortableTh from '../../components/SortableTh';
import useTableColumns from '../../hooks/useTableColumns';
import useSortedRows from '../../hooks/useSortedRows';
import { fetchCases, deleteCase, getExportUrl } from './api';
import api from '../../api/axios';
import { STATUS_OPTIONS, STAGE_OPTIONS, STAGE_LABELS } from './constants';
import LitigationForm from './LitigationForm';

const ALL_COLUMNS = [
  ['cnr_number', 'CNR No'],
  ['company', 'Company'],
  ['litigation_number', 'Litigation No'],
  ['petitioner', 'Petitioner'],
  ['respondent', 'Respondent'],
  ['stage', 'Stage'],
  ['next_hearing_date', 'Next Hearing'],
  ['status', 'Status'],
  ['balance', 'Balance'],
];

const DEFAULT_VISIBLE = [
  'litigation_number', 'company', 'petitioner', 'respondent',
  'stage', 'next_hearing_date', 'status', 'balance',
];

const STATUS_META = {
  active:    { label: 'Active',           icon: 'ti-circle-check',       avatarBg: 'bg-success-subtle text-success',     badge: 'badge-soft-success' },
  pending:   { label: 'Pending Hearing',  icon: 'ti-clock',              avatarBg: 'bg-warning-subtle text-warning',     badge: 'badge-soft-warning' },
  disposed:  { label: 'Disposed',         icon: 'ti-circle-x',           avatarBg: 'bg-info-subtle text-info',           badge: 'badge-soft-info' },
  settled:   { label: 'Settled',          icon: 'ti-badge',              avatarBg: 'bg-purple-subtle text-purple',       badge: 'badge-soft-purple' },
  dismissed: { label: 'Dismissed',        icon: 'ti-alert-triangle',     avatarBg: 'bg-danger-subtle text-danger',       badge: 'badge-soft-danger' },
  withdrawn: { label: 'Withdrawn',        icon: 'ti-player-skip-forward', avatarBg: 'bg-secondary-subtle text-secondary', badge: 'badge-soft-secondary' },
};
const STATUS_ORDER = ['active', 'pending', 'disposed', 'settled', 'dismissed', 'withdrawn'];

function formatDate(d) {
  if (!d) return '\u2014';
  const date = new Date(d);
  if (isNaN(date.getTime())) return d;
  return date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}

function formatINR(n) {
  return `\u20b9${Number(n || 0).toLocaleString('en-IN')}`;
}

function escapeHtml(str) {
  return String(str).replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));
}

function getPageWindow(current, last) {
  const delta = 1;
  const range = [];
  for (let i = 1; i <= last; i += 1) {
    if (i === 1 || i === last || (i >= current - delta && i <= current + delta)) range.push(i);
  }
  const withDots = [];
  let prev;
  range.forEach((i) => {
    if (prev) {
      if (i - prev === 2) withDots.push(prev + 1);
      else if (i - prev > 2) withDots.push('\u2026');
    }
    withDots.push(i);
    prev = i;
  });
  return withDots;
}

function LitigationListStyles() {
  return (
    <style>{`
      .lit-table thead th {
        font-size: 0.68rem; font-weight: 700; letter-spacing: 0.04em;
        text-transform: uppercase; color: var(--theme-secondary-color); border-bottom-width: 1px;
      }
      .lit-list-page .card-header,
      .lit-list-page h1, .lit-list-page h2, .lit-list-page h3,
      .lit-list-page h4, .lit-list-page h5, .lit-list-page h6 {
        font-family: "DM Sans", sans-serif !important;
      }
      .lit-kpi-card {
        border-radius: 12px !important;
        box-shadow: 0 1px 2px rgba(15, 23, 42, 0.04);
        transition: transform 0.15s ease, box-shadow 0.15s ease, border-color 0.15s ease;
      }
      .lit-kpi-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 20px rgba(15, 23, 42, 0.09);
        border-color: rgba(35, 109, 201, 0.35) !important;
      }
      .lit-table tbody tr.lit-hearing-soon { background-color: #fffbeb; }
      .lit-table tbody tr.lit-hearing-soon:hover { background-color: #fef3c7; }
      .lit-kpi-label {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        max-width: 100%;
        display: block;
      }
    `}</style>
  );
}

export default function LitigationList() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [data, setData] = useState([]);
  const [meta, setMeta] = useState(null);
  const [kpis, setKpis] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const [showForm, setShowForm] = useState(false);
  const [selectedId, setSelectedId] = useState(null);
  const [formMode, setFormMode] = useState('create');
  const [showAllKpis, setShowAllKpis] = useState(false);

  const search = searchParams.get('search') || '';
  const stageFilter = searchParams.get('stage') || '';
  const statusFilter = searchParams.get('status') || '';
  const page = parseInt(searchParams.get('page'), 10) || 1;

  const [searchInput, setSearchInput] = useState(search);
  useEffect(() => { setSearchInput(search); }, [search]);

  const {
    visibleCols, toggleCol, presets, activePresetName, applyPreset, savePreset, deletePreset,
  } = useTableColumns('litigation_list', ALL_COLUMNS, DEFAULT_VISIBLE);

  const searchTimer = useRef(null);
  useEffect(() => () => { if (searchTimer.current) clearTimeout(searchTimer.current); }, []);

  const loadData = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const result = await fetchCases({ search, stage: stageFilter, status: statusFilter, page });
      setData(result.data);
      setMeta(result.meta);
      setKpis(result.kpis);
    } catch (err) {
      setError(err.response?.data?.message || 'Could not load cases.');
    } finally {
      setLoading(false);
    }
  }, [search, stageFilter, statusFilter, page]);

  useEffect(() => { loadData(); }, [loadData]);

  function updateFilters(updates) {
    const newParams = new URLSearchParams(searchParams);
    Object.entries(updates).forEach(([key, value]) => {
      if (value) newParams.set(key, value);
      else newParams.delete(key);
    });
    if (updates.search !== undefined || updates.stage !== undefined || updates.status !== undefined) {
      newParams.set('page', '1');
    }
    setSearchParams(newParams);
  }

  function handleSearchChange(value) {
    setSearchInput(value);
    if (searchTimer.current) clearTimeout(searchTimer.current);
    searchTimer.current = setTimeout(() => { updateFilters({ search: value }); }, 500);
  }

  function clearFilters() {
    if (searchTimer.current) clearTimeout(searchTimer.current);
    setSearchParams({});
  }

  function handlePageChange(newPage) { updateFilters({ page: String(newPage) }); }

  function openCreateModal() { setSelectedId(null); setFormMode('create'); setShowForm(true); }
  function openEditModal(id) { setSelectedId(id); setFormMode('edit'); setShowForm(true); }
  function handleFormSuccess() { loadData(); }

  useEffect(() => {
    const editId = searchParams.get('edit');
    if (editId) {
      openEditModal(editId);
      searchParams.delete('edit');
      setSearchParams(searchParams, { replace: true });
    }
  }, []);

  async function handleDelete(item) {
    const confirmed = await Swal.fire({
      icon: 'warning',
      title: 'Delete this case?',
      html: `You're about to delete <b>${escapeHtml(item.litigation_number)}</b>. This cannot be undone.`,
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it',
      cancelButtonText: 'Cancel',
      confirmButtonColor: '#f7577e',
      cancelButtonColor: '#98a6ad',
      reverseButtons: true,
    });
    if (!confirmed.isConfirmed) return;
    try {
      await deleteCase(item.id);
      await loadData();
      Swal.fire({ icon: 'success', title: 'Deleted', timer: 1200, showConfirmButton: false });
    } catch (err) {
      Swal.fire({ icon: 'error', title: 'Cannot delete', text: err.response?.data?.message || 'Delete failed.', confirmButtonColor: '#236dc9' });
    }
  }

  const sortGetters = useMemo(() => ({
    cnr_number: (r) => r.cnr_number || '',
    company: (r) => r.company_name || '',
    litigation_number: (r) => r.litigation_number || '',
    petitioner: (r) => r.petitioner || '',
    respondent: (r) => r.respondent || '',
    stage: (r) => r.stage || '',
    next_hearing_date: (r) => r.next_hearing_date || '',
    status: (r) => r.status || '',
    balance: (r) => Number(r.balance ?? 0),
  }), []);
  const { sorted, sortState, onSort } = useSortedRows(data, sortGetters);

  const pageWindow = useMemo(() => (meta ? getPageWindow(page, meta.last_page) : []), [meta, page]);

  const exportParams = useMemo(() => {
    const params = {};
    if (search) params.search = search;
    if (stageFilter) params.stage = stageFilter;
    if (statusFilter) params.status = statusFilter;
    return params;
  }, [search, stageFilter, statusFilter]);

  async function handleExport() {
    try {
      const query = new URLSearchParams();
      Object.entries(exportParams).forEach(([key, value]) => {
        if (value !== '' && value !== undefined && value !== null) query.set(key, value);
      });
      const res = await api.get(`/litigation/export?${query.toString()}`, { responseType: 'blob' });
      const blobUrl = window.URL.createObjectURL(res.data);
      const a = document.createElement('a');
      a.href = blobUrl;
      a.download = 'litigation-register.csv';
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(blobUrl);
    } catch (err) {
      Swal.fire({ icon: 'error', title: 'Export failed', text: err.response?.data?.message || 'Could not export data.' });
    }
  }

  return (
    <div style={{ padding: '12px' }} className="lit-list-page">
      <LitigationListStyles />
      <Breadcrumb items={[{ label: 'Litigation', to: '/modules/litigation' }]} />

      <div className="page-title-head d-flex align-items-start flex-wrap gap-3 mb-3">
        <div className="d-flex align-items-start gap-3 flex-grow-1">
          <div className="avatar-md flex-shrink-0">
            <span className="avatar-title bg-primary-subtle text-primary rounded-3 fs-22">
<i className="ti ti-scale" />
            </span>
          </div>
          <div>
            <h4 className="page-main-title m-0">Litigation Register</h4>
            <p className="text-muted mb-0 fs-sm">Manage and track litigation cases, court proceedings, and legal matters.</p>
          </div>
        </div>
        <div className="d-flex flex-wrap gap-2">
          <button type="button" className="btn btn-primary btn-sm" onClick={openCreateModal}>
            <i className="ti ti-plus me-1" /> Add Litigation
          </button>
        </div>
      </div>

      {error && <Alert variant="danger" className="py-2">{error}</Alert>}

      {kpis && (
        <div className="mb-3">
          <div className="d-flex flex-wrap gap-2">
            <div style={{ flex: '1 1 0', minWidth: 118 }}>
              <button type="button" className="card mb-0 w-100 h-100 text-start border lit-kpi-card" style={{ cursor: 'pointer', borderColor: !statusFilter ? 'var(--bs-primary)' : undefined, borderWidth: !statusFilter ? 2 : 1 }} onClick={() => updateFilters({ status: '' })}>
                <div className="card-body d-flex align-items-center gap-2 py-2 px-2">
                  <div className="avatar-md flex-shrink-0"><span className="avatar-title bg-primary-subtle text-primary rounded-3 fs-20"><i className="ti ti-scale" /></span></div>
                  <div style={{ minWidth: 0 }}><h3 className="mb-0 fw-bold">{kpis.total || 0}</h3><p className="mb-0 fw-semibold fs-xs lit-kpi-label" style={{ color: 'var(--theme-emphasis-color)' }} title="Total Cases">Total Cases</p></div>
                </div>
              </button>
            </div>
            {STATUS_ORDER.slice(0, showAllKpis ? STATUS_ORDER.length : 3).map((status) => {
              const meta = STATUS_META[status];
              return (
                <div style={{ flex: '1 1 0', minWidth: 118 }} key={status}>
                  <button type="button" className="card mb-0 w-100 h-100 text-start border lit-kpi-card" style={{ cursor: 'pointer', borderColor: statusFilter === status ? 'var(--bs-primary)' : undefined, borderWidth: statusFilter === status ? 2 : 1 }} onClick={() => updateFilters({ status })}>
                    <div className="card-body d-flex align-items-center gap-2 py-2 px-2">
                      <div className="avatar-md flex-shrink-0"><span className={`avatar-title rounded-3 fs-20 ${meta.avatarBg}`}><i className={`ti ${meta.icon}`} /></span></div>
                      <div><h3 className="mb-0 fw-bold">{kpis[status] || 0}</h3><p className="mb-0 fw-semibold fs-xs lit-kpi-label" style={{ color: 'var(--theme-emphasis-color)' }} title={meta.label}>{meta.label}</p></div>
                    </div>
                  </button>
                </div>
              );
            })}
            {showAllKpis && (
              <div style={{ flex: '1 1 0', minWidth: 118 }}>
                <div className="card mb-0 w-100 h-100 text-start border lit-kpi-card">
                  <div className="card-body d-flex align-items-center gap-2 py-2 px-2">
                    <div className="avatar-md flex-shrink-0"><span className="avatar-title bg-danger-subtle text-danger rounded-3 fs-20"><i className="ti ti-clock" /></span></div>
                    <div><h3 className="mb-0 fw-bold">{kpis.hearings_soon || 0}</h3><p className="mb-0 fw-semibold fs-xs lit-kpi-label" style={{ color: 'var(--theme-emphasis-color)' }} title="Hearings Soon">Hearings Soon</p></div>
                  </div>
                </div>
              </div>
            )}
          </div>
          {STATUS_ORDER.length > 3 && (
            <div className="text-end mt-1">
              <button type="button" className="btn btn-link btn-sm text-muted p-0" onClick={() => setShowAllKpis(!showAllKpis)}>
                <i className={`ti ti-chevron-${showAllKpis ? 'up' : 'down'} me-1`} />{showAllKpis ? 'Show Less' : `Show All (${STATUS_ORDER.length + 1})`}
              </button>
            </div>
          )}
        </div>
      )}

      <div className="card mb-3">
        <div className="card-body d-flex flex-wrap gap-2 py-3">
          <div className="app-search flex-grow-1" style={{ minWidth: 220 }}>
            <input type="search" className="form-control" placeholder="Search litigation number, petitioner, respondent, court..." value={searchInput} onChange={(e) => handleSearchChange(e.target.value)} />
            <i className="ti ti-search app-search-icon text-muted" />
          </div>
          <select className="form-select" style={{ maxWidth: 190 }} value={stageFilter} onChange={(e) => updateFilters({ stage: e.target.value })}>
            <option value="">All Stages</option>
            {STAGE_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
          <select className="form-select" style={{ maxWidth: 190 }} value={statusFilter} onChange={(e) => updateFilters({ status: e.target.value })}>
            <option value="">All Statuses</option>
            {STATUS_OPTIONS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>
          {(search || stageFilter || statusFilter) && (
            <button type="button" className="btn btn-outline-secondary btn-sm" onClick={clearFilters}>
              <i className="ti ti-x" /> Reset
            </button>
          )}
        </div>
      </div>

      <div className="card">
        <div className="card-header d-flex align-items-center gap-2 flex-wrap">
          <i className="ti ti-scale text-primary" />
          <span className="fw-semibold fs-sm">Litigation Cases</span>
          <Badge bg="primary" className="fw-bold fs-sm">{meta?.total || 0} Records</Badge>
          <div className="ms-auto d-flex gap-1">
            <button type="button" className="btn btn-outline-secondary btn-sm d-flex align-items-center gap-1" title="Export to CSV" onClick={handleExport}>
              <i className="ti ti-download" /> Export
            </button>
            <TableColumnsControl
              allColumns={ALL_COLUMNS}
              visibleCols={visibleCols}
              toggleCol={toggleCol}
              presets={presets}
              activePresetName={activePresetName}
              applyPreset={applyPreset}
              savePreset={savePreset}
              deletePreset={deletePreset}
            />
          </div>
        </div>
        <div className="card-body p-0">
          {loading ? (
            <div className="text-center py-4"><Spinner animation="border" size="sm" /> <span className="ms-2">Loading...</span></div>
          ) : (
            <div className="table-responsive">
              <table className="table table-custom table-centered table-hover lit-table w-100 mb-0">
                <thead className="bg-light align-middle bg-opacity-25 thead-sm">
                  <tr className="text-uppercase fs-xxs">
                    <th style={{ width: '1%' }}>#</th>
                    {ALL_COLUMNS.filter(([key]) => visibleCols.has(key)).map(([key, label]) => (
                      <SortableTh key={key} label={label} sortKey={key} sortState={sortState} onSort={onSort} />
                    ))}
                    <th className="text-center" style={{ width: '1%' }}>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {sorted.length === 0 && (
                    <tr><td colSpan={visibleCols.size + 2} className="text-center py-5 text-muted">
                      <i className="ti ti-file-off fs-1 d-block mb-2 opacity-50" /> No litigation cases found
                    </td></tr>
                  )}
                  {sorted.map((item, idx) => (
                    <tr key={item.id} className={item.is_hearing_soon ? 'lit-hearing-soon' : ''}>
                      <td className="text-muted">{(meta?.from || 1) + idx}</td>
                      {visibleCols.has('cnr_number') && <td className="text-muted" style={{ fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace', fontSize: '0.75rem' }}>{item.cnr_number || '\u2014'}</td>}
                      {visibleCols.has('company') && <td>{item.company_name || '\u2014'}</td>}
                      {visibleCols.has('litigation_number') && <td className="fw-semibold" style={{ fontFamily: 'ui-monospace, SFMono-Regular, Menlo, monospace' }}>{item.litigation_number || '\u2014'}</td>}
                      {visibleCols.has('petitioner') && <td>{item.petitioner || '\u2014'}</td>}
                      {visibleCols.has('respondent') && <td>{item.respondent || '\u2014'}</td>}
                      {visibleCols.has('stage') && <td>{STAGE_LABELS[item.stage] || item.stage}</td>}
                      {visibleCols.has('next_hearing_date') && <td>{formatDate(item.next_hearing_date)}</td>}
                      {visibleCols.has('status') && <td><span className={`badge ${(STATUS_META[item.status] || {}).badge || 'badge-soft-secondary'} fs-xxs`}>{(STATUS_META[item.status] || {}).label || item.status}</span></td>}
                      {visibleCols.has('balance') && <td className={`fw-semibold ${(item.balance ?? 0) > 0 ? 'text-warning' : 'text-success'}`}>{formatINR(item.balance)}</td>}
                      <td>
                        <div className="d-flex justify-content-center gap-1">
                          <Link to={`/modules/litigation/litigation-register/${item.id}/view`} className="btn btn-default btn-icon btn-sm" title="View"><i className="ti ti-eye fs-lg" /></Link>
                          <button onClick={() => openEditModal(item.id)} className="btn btn-default btn-icon btn-sm" title="Edit"><i className="ti ti-pencil fs-lg" /></button>
                          <button onClick={() => handleDelete(item)} className="btn btn-default btn-icon btn-sm" title="Delete"><i className="ti ti-trash fs-lg text-danger" /></button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {meta && meta.last_page > 1 && (
        <div className="d-flex justify-content-between align-items-center mt-3 flex-wrap gap-2">
          <small className="text-muted">Showing {meta.from}\u2013{meta.to} of {meta.total} cases</small>
          <nav>
            <ul className="pagination pagination-sm mb-0">
              <li className={`page-item ${page <= 1 ? 'disabled' : ''}`}>
                <button className="page-link" onClick={() => handlePageChange(page - 1)}>Previous</button>
              </li>
              {pageWindow.map((p, idx) => (
                p === '\u2026' ? (
                  <li key={`dots-${idx}`} className="page-item disabled"><span className="page-link">\u2026</span></li>
                ) : (
                  <li key={p} className={`page-item ${p === page ? 'active' : ''}`}>
                    <button className="page-link" onClick={() => handlePageChange(p)}>{p}</button>
                  </li>
                )
              ))}
              <li className={`page-item ${page >= meta.last_page ? 'disabled' : ''}`}>
                <button className="page-link" onClick={() => handlePageChange(page + 1)}>Next</button>
              </li>
            </ul>
          </nav>
        </div>
      )}

      <LitigationForm show={showForm} onHide={() => setShowForm(false)} onSuccess={handleFormSuccess} id={formMode === 'edit' ? selectedId : null} />
    </div>
  );
}
