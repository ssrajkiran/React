import { useCallback, useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Spinner, Badge } from 'react-bootstrap';
import Swal from 'sweetalert2';
import Breadcrumb from '../../components/Breadcrumb';
import { fetchCase, deleteCase, getDocumentDownloadUrl, fetchDocumentBlob } from './api';
import {
  STATUS_OPTIONS,
  STAGE_LABELS,
  CASE_TYPES,
  FILE_ICON_MAP,
  DEFAULT_FILE_ICON,
} from './constants';

function money(v) { if (v === null || v === undefined || v === '') return '\u2014'; return `\u20b9${Number(v).toLocaleString('en-IN')}`; }
function formatDate(d) { if (!d) return '\u2014'; return new Date(d).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }); }
function formatDateTime(d) { if (!d) return '\u2014'; return new Date(d).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }); }
function getCompanyName(company) { if (!company) return '\u2014'; return company.company_name || company.name || company.code || '\u2014'; }
function getFileIcon(mimeType) { return FILE_ICON_MAP[mimeType] || DEFAULT_FILE_ICON; }

const STATUS_META = {
  active:    { label: 'Active',           badge: 'badge-soft-success text-success' },
  pending:   { label: 'Pending Hearing',  badge: 'badge-soft-warning text-warning' },
  disposed:  { label: 'Disposed',         badge: 'badge-soft-info text-info' },
  settled:   { label: 'Settled',          badge: 'badge-soft-purple text-purple' },
  dismissed: { label: 'Dismissed',        badge: 'badge-soft-danger text-danger' },
  withdrawn: { label: 'Withdrawn',        badge: 'badge-soft-secondary text-secondary' },
};

const TABS = [
  ['overview', 'Overview', 'ti-list-details'],
  ['advocates', 'Advocates', 'ti-users'],
  ['status', 'Case Status', 'ti-gavel'],
  ['fee', 'Advocate Fee', 'ti-currency-rupee'],
  ['documents', 'Documents', 'ti-folder'],
];

function SectionHeader({ icon, open, onToggle, children }) {
  return (
    <div
      className="card-header d-flex align-items-center gap-2 flex-wrap"
      role="button"
      onClick={onToggle}
      aria-expanded={open}
      style={{ cursor: 'pointer', userSelect: 'none' }}
    >
      <span>
        <i className={`ti ${icon} text-primary me-1`} /> {children}
      </span>
      <i className={`ti ${open ? 'ti-chevron-up' : 'ti-chevron-down'} ms-auto`} style={{ color: 'var(--theme-secondary-color)', transition: 'transform 0.15s ease' }} />
    </div>
  );
}

function AuthDocumentLink({ caseId, doc }) {
  const [previewUrl, setPreviewUrl] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => { return () => { if (previewUrl) URL.revokeObjectURL(previewUrl); }; }, [previewUrl]);

  const handlePreview = async () => {
    setLoading(true);
    try {
      const blob = await fetchDocumentBlob(caseId, doc.id);
      const url = URL.createObjectURL(blob);
      setPreviewUrl(url);
      window.open(url, '_blank');
    } catch (err) {
      Swal.fire({ icon: 'error', title: 'Could not open document', text: err.message });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="d-flex align-items-center gap-1">
      <button
        type="button"
        className="btn btn-sm btn-outline-secondary"
        title="Preview"
        onClick={(e) => {
          if (doc.file_type?.startsWith('image/') || doc.file_type === 'application/pdf') {
            e.preventDefault();
            handlePreview();
          } else {
            window.open(getDocumentDownloadUrl(caseId, doc.id), '_blank');
          }
        }}
      >
        {loading ? <Spinner animation="border" size="sm" /> : <i className="ti ti-eye" />}
      </button>
      <a href={getDocumentDownloadUrl(caseId, doc.id)} className="btn btn-sm btn-outline-secondary" title="Download">
        <i className="ti ti-download" />
      </a>
    </div>
  );
}

function scrollAncestorsToTop() {
  window.scrollTo(0, 0);
  document.documentElement.scrollTop = 0;
  document.body.scrollTop = 0;
}

export default function LitigationView() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [caseData, setCaseData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('overview');
  const [openSections, setOpenSections] = useState({ header: true });
  const toggleSection = (key) => setOpenSections((s) => ({ ...s, [key]: !s[key] }));

  useEffect(() => { scrollAncestorsToTop(); }, [tab]);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await fetchCase(id);
      setCaseData(data);
    } catch {
      Swal.fire({ icon: 'error', title: 'Case not found', confirmButtonColor: '#236dc9' });
      navigate('/modules/litigation/litigation-register');
    } finally {
      setLoading(false);
    }
  }, [id, navigate]);

  useEffect(() => { load(); }, [load]);

  async function handleDelete() {
    const result = await Swal.fire({
      icon: 'warning',
      title: `Delete ${caseData.litigation_number}?`,
      html: `<div style="text-align:left;font-size:0.85rem;color:#991B1B;background:#FEF2F2;border:1px solid #FECACA;border-radius:8px;padding:12px 14px;margin-bottom:10px">This litigation case will be permanently deleted. This cannot be undone.</div>`,
      showCancelButton: true,
      confirmButtonText: 'Delete',
      confirmButtonColor: '#dc3545',
    });
    if (!result.isConfirmed) return;

    try {
      await deleteCase(caseData.id);
      await Swal.fire({ icon: 'success', title: 'Case deleted', timer: 1600, showConfirmButton: false });
      navigate('/modules/litigation/litigation-register');
    } catch (err) {
      Swal.fire({ icon: 'error', title: 'Could not delete', text: err.response?.data?.message });
    }
  }

  if (loading) return <div className="text-center py-5"><Spinner animation="border" size="sm" /> <span className="ms-2">Loading...</span></div>;
  if (!caseData) return null;

  const fee = Number(caseData.advocate_fee || 0);
  const paid = Number(caseData.paid_amount || 0);
  const balance = Number(caseData.balance ?? Math.max(fee - paid, 0));
  const paidPct = fee > 0 ? Math.min(100, Math.round((paid / fee) * 100)) : 0;
  const statusMeta = STATUS_META[caseData.status] || {};

  return (
    <div className="lvm-view-page">
      <style>{`
        .lvm-label {
          font-size: 0.66rem;
          font-weight: 700;
          letter-spacing: 0.06em;
          text-transform: uppercase;
          color: var(--theme-emphasis-color);
          margin-bottom: 3px;
        }
        .lvm-value {
          font-size: 0.85rem;
          font-weight: 500;
          color: var(--theme-body-color);
          line-height: 1.35;
          min-width: 0;
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;
        }
        .lvm-value.lvm-value-wrap {
          white-space: normal;
          overflow: visible;
          text-overflow: clip;
        }
        .lvm-value.is-empty { color: #cbd5e1; }
        .lvm-hero-stat { background: var(--theme-tertiary-bg, #f8fafc); border: 1px solid var(--theme-border-color, rgba(15,23,42,0.06)); border-radius: 10px; padding: 10px 18px; min-width: 130px; }
        .bv-hero-stat-value { font-size: 1.15rem; font-weight: 700; color: var(--theme-body-color); line-height: 1.3; }
        .bi-header-label { font-size: 0.68rem; font-weight: 700; letter-spacing: 0.05em; text-transform: uppercase; color: var(--theme-secondary-color); margin-bottom: 2px; }
        .bi-header-value { font-size: 0.9rem !important; font-weight: 700 !important; color: var(--theme-body-color) !important; min-width: 0 !important; max-width: 100% !important; overflow: hidden !important; white-space: nowrap !important; text-overflow: ellipsis !important; display: block !important; }
        .lvm-tabs-wrap { overflow-x: auto; }
        .lvm-tabs-wrap .nav-tabs { flex-wrap: nowrap; gap: 6px; }
        .lvm-tabs-wrap .nav-item { flex-shrink: 0; }
        .lvm-tabs-wrap .nav-link {
          display: flex; align-items: center; justify-content: center; gap: 6px;
          font-size: 0.85rem; font-weight: 500; white-space: nowrap;
          min-width: 96px; padding: 0.6rem 1.1rem;
        }
        .lvm-stat { border-radius: 10px; padding: 0.7rem 0.8rem; background: var(--theme-tertiary-bg, #f8fafc); border: 1px solid rgba(15,23,42,0.05); }
        .lvm-stat-figure { font-size: 1rem; font-weight: 700; }
        .lvm-progress { height: 6px; border-radius: 999px; background: rgba(148,163,184,0.25); overflow: hidden; margin-top: 8px; }
        .lvm-progress > span { display: block; height: 100%; background: linear-gradient(90deg, #10B981, #059669); border-radius: 999px; transition: width .4s ease; }
        .lvm-doc-row { display: flex; align-items: center; gap: 0.75rem; padding: 0.6rem 0.75rem; border-radius: 10px; border: 1px solid rgba(15,23,42,0.06); background: #fff; margin-bottom: 0.5rem; transition: border-color .15s ease, box-shadow .15s ease; }
        .lvm-doc-row:last-child { margin-bottom: 0; }
        .lvm-doc-row:hover { border-color: rgba(35,109,201,0.35); box-shadow: 0 3px 10px rgba(15,23,42,0.05); }
        .lvm-doc-icon { display: flex; align-items: center; justify-content: center; width: 36px; height: 36px; border-radius: 9px; flex-shrink: 0; font-size: 1rem; }
        .lvm-fade-in { animation: lvm-fade .25s ease both; }
        @keyframes lvm-fade { from { opacity: 0; transform: translateY(4px); } to { opacity: 1; transform: translateY(0); } }
        @media (prefers-reduced-motion: reduce) { .lvm-fade-in { animation: none; } }
      `}</style>

      <Breadcrumb
        items={[{ label: 'Litigation', to: '/modules/litigation' }, { label: 'Register', to: '/modules/litigation/litigation-register' }, { label: caseData.litigation_number }]}
        right={<Link to="/modules/litigation/litigation-register" className="text-muted fs-sm text-decoration-none"><i className="ti ti-arrow-left me-1" /> Back to Register</Link>}
      />

      <div className="card mb-3 position-relative overflow-hidden">
        <SectionHeader icon="ti-scale" open={openSections.header} onToggle={() => toggleSection('header')}>Litigation Case</SectionHeader>
        {openSections.header && (
        <div className="card-body">
          <div className="d-flex flex-wrap gap-4 align-items-start justify-content-between">
            <div className="d-flex flex-column gap-1" style={{ minWidth: 220 }}>
              <h4 className="fw-bold mb-1">{caseData.petitioner} vs {caseData.respondent}</h4>
              <div className="fs-sm" style={{ color: 'var(--theme-secondary-color)' }}>
                Case No: <span className="fw-bold" style={{ color: 'var(--theme-body-color)' }}>{caseData.litigation_number}</span>
              </div>
              {caseData.cnr_number && (
                <div className="fs-sm" style={{ color: 'var(--theme-secondary-color)' }}>
                  CNR: <span className="fw-bold" style={{ color: 'var(--theme-body-color)' }}>{caseData.cnr_number}</span>
                </div>
              )}
              <div className="fs-sm d-flex align-items-center gap-1 mt-1">
                <i className="ti ti-building" style={{ color: 'var(--theme-body-color)' }} />
                <span className="fw-semibold">{getCompanyName(caseData.company)}</span>
              </div>
              <div className="fs-sm d-flex align-items-center gap-1">
                <i className="ti ti-calendar" style={{ color: 'var(--theme-body-color)' }} /> Court:{' '}
                <span className="fw-semibold">{caseData.court_name}</span>
              </div>
            </div>

            <div className="d-flex flex-wrap gap-3">
              <div className="lvm-hero-stat">
                <div className="bi-header-label">Total Fee</div>
                <div className="bv-hero-stat-value" title={money(fee)}>{money(fee)}</div>
              </div>
              <div className="lvm-hero-stat">
                <div className="bi-header-label">Paid</div>
                <div className="bv-hero-stat-value" style={{ color: '#059669' }} title={money(paid)}>{money(paid)}</div>
              </div>
              <div className="lvm-hero-stat">
                <div className="bi-header-label">Balance</div>
                <div className="bv-hero-stat-value" style={{ color: balance > 0 ? '#d97706' : '#059669' }} title={money(balance)}>{money(balance)}</div>
              </div>
            </div>

            <div className="d-flex flex-column align-items-stretch gap-2" style={{ minWidth: 150 }}>
              {caseData.status && (
                <span className={`badge ${statusMeta.badge} rounded-pill px-2 py-1 fs-xxs fw-semibold align-self-end mb-1`}>
                  {statusMeta.label}
                </span>
              )}
              <Link to={`/modules/litigation/litigation-register?edit=${caseData.id}`} className="btn btn-sm btn-warning text-white px-2 text-center">
                <i className="ti ti-pencil me-1" /> Edit Case
              </Link>
              <button className="btn btn-sm btn-danger px-2" onClick={handleDelete}>
                <i className="ti ti-trash me-1" /> Delete Case
              </button>
            </div>
          </div>
        </div>
        )}
      </div>

      <div className="card mb-3">
        <div className="card-header lvm-tabs-wrap">
          <ul className="nav nav-tabs nav-bordered mb-0" style={{ flexWrap: 'nowrap' }}>
            {TABS.map(([key, label, icon]) => (
              <li className="nav-item" key={key} style={{ flexShrink: 0 }}>
                <button type="button" className={`nav-link ${tab === key ? 'active' : ''}`} onClick={() => setTab(key)}>
                  <i className={`ti ${icon} me-1`} /> {label}
                </button>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {tab === 'overview' && (
        <div className="card">
          <div className="card-header"><i className="ti ti-scale text-primary me-1" /> Overview</div>
          <div className="card-body">
            <div className="row g-3">
              {/* Case Information */}
              <div className="col-12">
                <div className="bi-header-label mb-2" style={{ fontSize: '0.75rem', borderBottom: '1px solid var(--theme-border-color, rgba(15,23,42,0.06))', paddingBottom: '6px' }}>
                  <i className="ti ti-file-text text-primary me-1" /> Case Information
                </div>
                <div className="row g-3">
                  <div className="col-md-3"><div className="lvm-label">Litigation Number</div><div className="bi-header-value">{caseData.litigation_number}</div></div>
                  <div className="col-md-3"><div className="lvm-label">CNR Number</div><div className="lvm-value">{caseData.cnr_number || '\u2014'}</div></div>
                  <div className="col-md-3"><div className="lvm-label">Case Type</div><div className="lvm-value">{CASE_TYPES[caseData.case_type] || caseData.case_type}</div></div>
                  <div className="col-md-3"><div className="lvm-label">Court Name</div><div className="lvm-value">{caseData.court_name}</div></div>
                  <div className="col-md-3"><div className="lvm-label">Jurisdiction</div><div className="lvm-value">{caseData.jurisdiction || '\u2014'}</div></div>
                  <div className="col-md-3"><div className="lvm-label">Location</div><div className="lvm-value">{caseData.location || '\u2014'}</div></div>
                </div>
              </div>

              {/* Parties */}
              <div className="col-12">
                <div className="bi-header-label mb-2" style={{ fontSize: '0.75rem', borderBottom: '1px solid var(--theme-border-color, rgba(15,23,42,0.06))', paddingBottom: '6px' }}>
                  <i className="ti ti-users text-primary me-1" /> Parties
                </div>
                <div className="row g-3">
                  <div className="col-md-3"><div className="lvm-label">Petitioner</div><div className="bi-header-value">{caseData.petitioner}</div></div>
                  <div className="col-md-3"><div className="lvm-label">Respondent</div><div className="bi-header-value">{caseData.respondent}</div></div>
                  <div className="col-md-3"><div className="lvm-label">Case Representative</div><div className="lvm-value">{caseData.case_representative || '\u2014'}</div></div>
                </div>
              </div>

              {/* Company & Subject */}
              <div className="col-12">
                <div className="bi-header-label mb-2" style={{ fontSize: '0.75rem', borderBottom: '1px solid var(--theme-border-color, rgba(15,23,42,0.06))', paddingBottom: '6px' }}>
                  <i className="ti ti-building text-primary me-1" /> Company & Subject
                </div>
                <div className="row g-3">
                  <div className="col-md-3"><div className="lvm-label">Company</div><div className="lvm-value">{getCompanyName(caseData.company)}</div></div>
                  <div className="col-md-9"><div className="lvm-label">Subject</div><div className="lvm-value">{caseData.subject || '\u2014'}</div></div>
                </div>
              </div>

              {caseData.facts && (
                <div className="col-12">
                  <div className="lvm-label mb-1">Facts</div>
                  <div className="fs-sm bg-light border rounded p-2 lvm-value-wrap" style={{ whiteSpace: 'pre-wrap' }}>{caseData.facts}</div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {tab === 'advocates' && (
        <div className="card">
          <div className="card-header"><i className="ti ti-users text-primary me-1" /> Advocates</div>
          <div className="card-body">
            <div className="row g-3">
              <div className="col-md-6">
                <div className="card h-100">
                  <div className="card-header"><i className="ti ti-user text-primary me-1" /> Petitioner Advocate</div>
                  <div className="card-body">
                    <div className="row g-3">
                      <div className="col-12"><div className="lvm-label">Name</div><div className="lvm-value">{caseData.petitioner_advocate_name || '\u2014'}</div></div>
                      <div className="col-12"><div className="lvm-label">Contact</div><div className="lvm-value">{caseData.petitioner_advocate_contact ? `+91 ${caseData.petitioner_advocate_contact}` : '\u2014'}</div></div>
                      <div className="col-12"><div className="lvm-label">Email</div><div className="lvm-value">{caseData.petitioner_advocate_email || '\u2014'}</div></div>
                      <div className="col-12"><div className="lvm-label">Address</div><div className="lvm-value">{caseData.petitioner_advocate_address || '\u2014'}</div></div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-6">
                <div className="card h-100">
                  <div className="card-header"><i className="ti ti-user text-danger me-1" /> Respondent Advocate</div>
                  <div className="card-body">
                    <div className="row g-3">
                      <div className="col-12"><div className="lvm-label">Name</div><div className="lvm-value">{caseData.respondent_advocate_name || '\u2014'}</div></div>
                      <div className="col-12"><div className="lvm-label">Contact</div><div className="lvm-value">{caseData.respondent_advocate_contact ? `+91 ${caseData.respondent_advocate_contact}` : '\u2014'}</div></div>
                      <div className="col-12"><div className="lvm-label">Email</div><div className="lvm-value">{caseData.respondent_advocate_email || '\u2014'}</div></div>
                      <div className="col-12"><div className="lvm-label">Address</div><div className="lvm-value">{caseData.respondent_advocate_address || '\u2014'}</div></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {tab === 'status' && (
        <div className="card">
          <div className="card-header"><i className="ti ti-gavel text-primary me-1" /> Case Status</div>
          <div className="card-body">
            <div className="row g-3">
              <div className="col-md-4"><div className="lvm-label">Stage</div><div className="lvm-value">{STAGE_LABELS[caseData.stage] || caseData.stage}</div></div>
              <div className="col-md-4"><div className="lvm-label">Next Hearing Date</div><div className="lvm-value">{formatDate(caseData.next_hearing_date)}</div></div>
              <div className="col-md-4">
                <div className="lvm-label">Status</div>
                {caseData.status ? (
                  <span className={`badge ${statusMeta.badge} rounded-pill fs-xxs fw-semibold`}>{statusMeta.label}</span>
                ) : <span className="lvm-value is-empty">\u2014</span>}
              </div>
              <div className="col-12"><div className="lvm-label">Remarks</div><div className="lvm-value">{caseData.remarks || '\u2014'}</div></div>
            </div>
          </div>
        </div>
      )}

      {tab === 'fee' && (
        <div className="card">
          <div className="card-header"><i className="ti ti-currency-rupee text-primary me-1" /> Advocate Fee</div>
          <div className="card-body">
            <div className="row g-3">
              <div className="col-md-4">
                <div className="lvm-stat">
                  <div className="lvm-label">Total Fee</div>
                  <div className="lvm-stat-figure">{money(fee)}</div>
                </div>
              </div>
              <div className="col-md-4">
                <div className="lvm-stat">
                  <div className="lvm-label">Paid</div>
                  <div className="lvm-stat-figure" style={{ color: '#059669' }}>{money(paid)}</div>
                </div>
              </div>
              <div className="col-md-4">
                <div className="lvm-stat">
                  <div className="lvm-label">Balance Due</div>
                  <div className="lvm-stat-figure" style={{ color: balance > 0 ? '#d97706' : '#059669' }}>{money(balance)}</div>
                </div>
              </div>
              <div className="col-12">
                <div className="lvm-stat">
                  <div className="d-flex justify-content-between align-items-baseline">
                    <div className="lvm-label mb-0">Payment Progress</div>
                    <span className="fw-semibold" style={{ fontSize: '0.95rem', color: balance > 0 ? '#d97706' : '#059669' }}>{paidPct}% paid</span>
                  </div>
                  <div className="lvm-progress">
                    <span style={{ width: `${paidPct}%` }} />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {tab === 'documents' && (
        <div className="card">
          <div className="card-header"><i className="ti ti-folder text-primary me-1" /> Documents {caseData.documents?.length > 0 && <Badge bg="secondary" className="ms-1">{caseData.documents.length}</Badge>}</div>
          <div className="card-body">
            {!caseData.documents || caseData.documents.length === 0 ? (
              <div className="text-center py-4 text-muted"><i className="ti ti-folder-off fs-1 d-block mb-2 opacity-50" /> No documents uploaded</div>
            ) : (
              caseData.documents.map((doc) => {
                const icon = getFileIcon(doc.file_type);
                return (
                  <div key={doc.id} className="lvm-doc-row">
                    <span className="lvm-doc-icon" style={{ backgroundColor: `${icon.color}1a`, color: icon.color }}>
                      <i className={`fas ${icon.icon}`} />
                    </span>
                    <div className="flex-grow-1 min-width-0">
                      <div className="text-truncate lvm-value" style={{ fontWeight: 600 }}>{doc.file_name || '\u2014'}</div>
                      <small className="text-muted">{doc.file_size_formatted || '\u2014'}</small>
                    </div>
                    <AuthDocumentLink caseId={id} doc={doc} />
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      <div className="mt-3">
        <div className="row g-2 text-muted" style={{ fontSize: '0.7rem' }}>
          <div className="col-auto">Created: {formatDateTime(caseData.created_at)} {caseData.created_by?.name ? `by ${caseData.created_by.name}` : ''}</div>
          {caseData.updated_at && <div className="col-auto ms-auto">Updated: {formatDateTime(caseData.updated_at)}</div>}
        </div>
      </div>
    </div>
  );
}
