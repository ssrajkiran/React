import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { vi, describe, it, expect, beforeEach } from 'vitest';
import LitigationForm from '../LitigationForm';

vi.mock('../api', () => ({
  fetchCase: vi.fn(),
  createCase: vi.fn().mockResolvedValue({ id: 1 }),
  updateCase: vi.fn(),
  fetchCompanies: vi.fn().mockResolvedValue([]),
}));

vi.mock('../../../components/DatePickerField', () => ({
  default: ({ value, onChange, placeholder }) => (
    <input data-testid="datepicker" placeholder={placeholder} value={value || ''} onChange={(e) => onChange(e.target.value)} />
  ),
}));

vi.mock('../../../components/SearchableSelect', () => ({
  default: ({ options, value, onChange, placeholder }) => (
    <select data-testid="searchable-select" value={value || ''} onChange={(e) => { if (onChange) onChange({ id: e.target.value }); }}>
      <option value="">{placeholder}</option>
      {options.map((o) => <option key={o.id} value={o.id}>{o.label}</option>)}
    </select>
  ),
}));

vi.mock('../DocumentDropzone', () => ({
  default: () => <div data-testid="document-dropzone" />,
}));

const defaultProps = { show: true, onHide: vi.fn(), onSuccess: vi.fn(), id: null };

function renderForm(props = {}) {
  return render(<LitigationForm {...defaultProps} {...props} />);
}

describe('LitigationForm - Create Mode', () => {
  beforeEach(() => vi.clearAllMocks());

  it('renders the modal when show is true', () => {
    renderForm();
    expect(screen.getByText('Add Litigation Case')).toBeInTheDocument();
  });

  it('does not render when show is false', () => {
    renderForm({ show: false });
    expect(screen.queryByText('Add Litigation Case')).not.toBeInTheDocument();
  });

  it('displays all 5 stepper steps', () => {
    renderForm();
    expect(screen.getByText('Basic Info')).toBeInTheDocument();
    expect(screen.getByText('Advocates')).toBeInTheDocument();
    expect(screen.getByText('Case Status')).toBeInTheDocument();
    expect(screen.getByText('Fee')).toBeInTheDocument();
    expect(screen.getByText('Documents')).toBeInTheDocument();
  });

  it('shows step 1 fields initially', () => {
    renderForm();
    expect(screen.getByText('Court Name')).toBeInTheDocument();
    expect(screen.getByText('Petitioner / Plaintiff')).toBeInTheDocument();
    expect(screen.getByText('Respondent / Defendant')).toBeInTheDocument();
    expect(screen.getByText('Litigation Number')).toBeInTheDocument();
  });

  it('shows Next button on first step', () => {
    renderForm();
    expect(screen.getByRole('button', { name: /Next/ })).toBeInTheDocument();
  });

  it('does not show Back button on first step', () => {
    renderForm();
    expect(screen.queryByRole('button', { name: /Back/ })).not.toBeInTheDocument();
  });

  it('validates required fields before advancing', async () => {
    const user = userEvent.setup();
    renderForm();
    await user.click(screen.getByRole('button', { name: /Next/ }));
    await waitFor(() => {
      expect(screen.getByText('Please fill all required fields before proceeding.')).toBeInTheDocument();
    });
  });

  it('advances to step 2 when required fields filled', async () => {
    const user = userEvent.setup();
    renderForm();
    await user.type(screen.getByPlaceholderText('e.g. High Court of Madras'), 'Delhi HC');
    await user.type(screen.getByPlaceholderText('Petitioner name'), 'John');
    await user.type(screen.getByPlaceholderText('Respondent name'), 'Jane');
    await user.type(screen.getByPlaceholderText('e.g. CS/123/2025'), 'LIT-001');
    const caseTypeSelect = screen.getAllByTestId('searchable-select')[1];
    await user.selectOptions(caseTypeSelect, 'AP');
    await user.click(screen.getByRole('button', { name: /Next/ }));
    await waitFor(() => {
      expect(screen.getByText('Petitioner Advocate')).toBeInTheDocument();
    });
  });

  it('shows Back button on step 2 and can go back', async () => {
    const user = userEvent.setup();
    renderForm();
    await user.type(screen.getByPlaceholderText('e.g. High Court of Madras'), 'Delhi HC');
    await user.type(screen.getByPlaceholderText('Petitioner name'), 'John');
    await user.type(screen.getByPlaceholderText('Respondent name'), 'Jane');
    await user.type(screen.getByPlaceholderText('e.g. CS/123/2025'), 'LIT-001');
    const caseTypeSelect = screen.getAllByTestId('searchable-select')[1];
    await user.selectOptions(caseTypeSelect, 'AP');
    await user.click(screen.getByRole('button', { name: /Next/ }));
    await waitFor(() => expect(screen.getByText('Petitioner Advocate')).toBeInTheDocument());
    await user.click(screen.getByRole('button', { name: /Back/ }));
    await waitFor(() => expect(screen.getByText('Court Name')).toBeInTheDocument());
  });

  it('calls onHide when close button clicked', async () => {
    const user = userEvent.setup();
    const onHide = vi.fn();
    renderForm({ onHide });
    await user.click(screen.getByRole('button', { name: /close/i }));
    expect(onHide).toHaveBeenCalled();
  });

  it('calls onHide when Cancel clicked', async () => {
    const user = userEvent.setup();
    const onHide = vi.fn();
    renderForm({ onHide });
    await user.click(screen.getByText('Cancel'));
    expect(onHide).toHaveBeenCalled();
  });

  it('navigates through all steps to documents', async () => {
    const user = userEvent.setup();
    renderForm();
    await user.type(screen.getByPlaceholderText('e.g. High Court of Madras'), 'Delhi HC');
    await user.type(screen.getByPlaceholderText('Petitioner name'), 'John');
    await user.type(screen.getByPlaceholderText('Respondent name'), 'Jane');
    await user.type(screen.getByPlaceholderText('e.g. CS/123/2025'), 'LIT-001');
    const caseTypeSelect = screen.getAllByTestId('searchable-select')[1];
    await user.selectOptions(caseTypeSelect, 'AP');
    await user.click(screen.getByRole('button', { name: /Next/ }));
    await waitFor(() => expect(screen.getByText('Petitioner Advocate')).toBeInTheDocument());
    await user.click(screen.getByRole('button', { name: /Next/ }));
    await waitFor(() => expect(screen.getByText('Stage')).toBeInTheDocument());
    await user.click(screen.getByRole('button', { name: /Next/ }));
    await waitFor(() => expect(screen.getByText('Advocate Fee')).toBeInTheDocument());
    await user.click(screen.getByRole('button', { name: /Next/ }));
    await waitFor(() => expect(screen.getByTestId('document-dropzone')).toBeInTheDocument());
    expect(screen.getByText('Save Case')).toBeInTheDocument();
  });
});
