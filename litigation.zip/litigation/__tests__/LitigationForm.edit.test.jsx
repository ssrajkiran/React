import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { vi, describe, it, expect, beforeEach } from 'vitest';
import Swal from 'sweetalert2';
import LitigationForm from '../LitigationForm';
import { fetchCase, updateCase } from '../api';

vi.mock('../api', () => ({
  fetchCase: vi.fn(),
  createCase: vi.fn(),
  updateCase: vi.fn().mockResolvedValue({ id: 1 }),
  fetchCompanies: vi.fn().mockResolvedValue([]),
}));

vi.mock('../../../components/DatePickerField', () => ({
  default: ({ value, onChange, placeholder }) => (
    <input data-testid="datepicker" placeholder={placeholder} value={value || ''} onChange={(e) => onChange(e.target.value)} />
  ),
}));

vi.mock('../../../components/SearchableSelect', () => ({
  default: ({ options, value, onChange, placeholder }) => (
    <select data-testid="searchable-select" value={value || ''} onChange={(e) => { if (onChange) onChange({ id: e.target.value }); }}>
      <option value="">{placeholder}</option>
      {options.map((o) => <option key={o.id} value={o.id}>{o.label}</option>)}
    </select>
  ),
}));

vi.mock('../DocumentDropzone', () => ({
  default: () => <div data-testid="document-dropzone" />,
}));

const mockCaseData = {
  id: 1, company_id: null, case_representative: 'Ram Kumar',
  court_name: 'Delhi High Court', jurisdiction: 'Delhi', location: 'New Delhi',
  petitioner: 'ABC Corp', respondent: 'XYZ Ltd', litigation_number: 'LIT-2025-001',
  cnr_number: 'CNR12345', case_type: 'AP', subject: 'Contract dispute',
  facts: 'Breach of contract',
  petitioner_advocate_name: 'Adv. Sharma', petitioner_advocate_contact: '9876543210',
  petitioner_advocate_email: 'sharma@law.com', petitioner_advocate_address: 'Delhi',
  respondent_advocate_name: 'Adv. Gupta', respondent_advocate_contact: '9876543211',
  respondent_advocate_email: 'gupta@law.com', respondent_advocate_address: 'Mumbai',
  stage: 'notice', next_hearing_date: '2025-08-15', status: 'active',
  advocate_fee: 100000, paid_amount: 50000, remarks: 'Urgent hearing', documents: [],
};

const defaultProps = { show: true, onHide: vi.fn(), onSuccess: vi.fn(), id: 1 };

function renderForm(props = {}) {
  return render(<LitigationForm {...defaultProps} {...props} />);
}

describe('LitigationForm - Edit Mode', () => {
  beforeEach(() => { vi.clearAllMocks(); fetchCase.mockResolvedValue(mockCaseData); });

  it('renders Edit Litigation Case title', async () => {
    renderForm();
    await waitFor(() => expect(screen.getByText('Edit Litigation Case')).toBeInTheDocument());
  });

  it('fetches and populates case data', async () => {
    renderForm();
    await waitFor(() => expect(fetchCase).toHaveBeenCalledWith(1));
    await waitFor(() => expect(screen.getByDisplayValue('Delhi High Court')).toBeInTheDocument());
  });

  it('shows Update button (not Next/Save)', async () => {
    renderForm();
    await waitFor(() => expect(screen.getByText('Update')).toBeInTheDocument());
    expect(screen.queryByRole('button', { name: /Next/ })).not.toBeInTheDocument();
    expect(screen.queryByText('Save Case')).not.toBeInTheDocument();
  });

  it('does not show Back button in edit mode', async () => {
    renderForm();
    await waitFor(() => expect(screen.getByText('Update')).toBeInTheDocument());
    expect(screen.queryByRole('button', { name: /Back/ })).not.toBeInTheDocument();
  });

  it('displays populated basic info fields', async () => {
    renderForm();
    await waitFor(() => expect(screen.getByDisplayValue('Delhi High Court')).toBeInTheDocument());
    expect(screen.getByDisplayValue('ABC Corp')).toBeInTheDocument();
    expect(screen.getByDisplayValue('XYZ Ltd')).toBeInTheDocument();
    expect(screen.getByDisplayValue('LIT-2025-001')).toBeInTheDocument();
    expect(screen.getByDisplayValue('CNR12345')).toBeInTheDocument();
    expect(screen.getByDisplayValue('Contract dispute')).toBeInTheDocument();
    expect(screen.getByDisplayValue('Breach of contract')).toBeInTheDocument();
    expect(screen.getByDisplayValue('Delhi')).toBeInTheDocument();
    expect(screen.getByDisplayValue('New Delhi')).toBeInTheDocument();
  });

  it('calls updateCase and shows success on Update', async () => {
    const user = userEvent.setup();
    Swal.fire.mockResolvedValue({ isConfirmed: false });
    renderForm();
    await waitFor(() => expect(screen.getByText('Update')).toBeInTheDocument());
    await user.click(screen.getByText('Update'));
    await waitFor(() => expect(updateCase).toHaveBeenCalled());
    await waitFor(() => expect(Swal.fire).toHaveBeenCalledWith(expect.objectContaining({ icon: 'success', title: 'Updated' })));
  });

  it('closes modal after successful update', async () => {
    const user = userEvent.setup();
    const onHide = vi.fn();
    Swal.fire.mockResolvedValue({ isConfirmed: false });
    renderForm({ onHide });
    await waitFor(() => expect(screen.getByText('Update')).toBeInTheDocument());
    await user.click(screen.getByText('Update'));
    await waitFor(() => expect(onHide).toHaveBeenCalled());
  });

  it('calls onSuccess after update', async () => {
    const user = userEvent.setup();
    const onSuccess = vi.fn();
    Swal.fire.mockResolvedValue({ isConfirmed: false });
    renderForm({ onSuccess });
    await waitFor(() => expect(screen.getByText('Update')).toBeInTheDocument());
    await user.click(screen.getByText('Update'));
    await waitFor(() => expect(onSuccess).toHaveBeenCalled());
  });

  it('shows validation error on 422', async () => {
    const user = userEvent.setup();
    updateCase.mockRejectedValue({ response: { status: 422, data: { errors: { court_name: ['Invalid'] } } } });
    Swal.fire.mockResolvedValue({ isConfirmed: false });
    renderForm();
    await waitFor(() => expect(screen.getByText('Update')).toBeInTheDocument());
    await user.click(screen.getByText('Update'));
    await waitFor(() => expect(Swal.fire).toHaveBeenCalledWith(expect.objectContaining({ icon: 'error', title: 'Validation Error', text: 'Invalid' })));
  });

  it('shows error on general failure', async () => {
    const user = userEvent.setup();
    updateCase.mockRejectedValue({ response: { status: 500, data: { message: 'Server error' } } });
    Swal.fire.mockResolvedValue({ isConfirmed: false });
    renderForm();
    await waitFor(() => expect(screen.getByText('Update')).toBeInTheDocument());
    await user.click(screen.getByText('Update'));
    await waitFor(() => expect(Swal.fire).toHaveBeenCalledWith(expect.objectContaining({ icon: 'error', title: 'Save failed', text: 'Server error' })));
  });

  it('closes modal on close button', async () => {
    const user = userEvent.setup();
    const onHide = vi.fn();
    renderForm({ onHide });
    await waitFor(() => expect(screen.getByText('Edit Litigation Case')).toBeInTheDocument());
    await user.click(screen.getByRole('button', { name: /close/i }));
    expect(onHide).toHaveBeenCalled();
  });

  it('closes modal on Cancel', async () => {
    const user = userEvent.setup();
    const onHide = vi.fn();
    renderForm({ onHide });
    await waitFor(() => expect(screen.getByText('Update')).toBeInTheDocument());
    await user.click(screen.getByText('Cancel'));
    expect(onHide).toHaveBeenCalled();
  });
});
