import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { vi, describe, it, expect, beforeEach } from 'vitest';
import Swal from 'sweetalert2';
import LitigationList from '../LitigationList';
import { fetchCases, deleteCase } from '../api';

vi.mock('../api', () => ({
  fetchCases: vi.fn(),
  createCase: vi.fn(),
  updateCase: vi.fn(),
  fetchCase: vi.fn(),
  deleteCase: vi.fn(),
  fetchCompanies: vi.fn().mockResolvedValue([]),
  getExportUrl: vi.fn().mockReturnValue('/api/litigation/export'),
}));

vi.mock('../../components/Breadcrumb', () => ({
  default: ({ items }) => (
    <nav data-testid="breadcrumb">
      {items.map((item, i) => (
        <span key={i}>{item.label}</span>
      ))}
    </nav>
  ),
}));

vi.mock('../../components/TableColumnsControl', () => ({
  default: () => <div data-testid="table-columns-control" />,
}));

vi.mock('../../components/SortableTh', () => ({
  default: ({ label, onSort, active }) => (
    <th onClick={() => onSort && onSort()} data-sort-active={active}>{label}</th>
  ),
}));

vi.mock('../../hooks/useTableColumns', () => ({
  default: () => ({
    visibleCols: ['litigation_number', 'company', 'petitioner', 'respondent', 'stage', 'next_hearing_date', 'status', 'balance'],
    toggleCol: vi.fn(),
    presets: [],
    activePresetName: '',
    applyPreset: vi.fn(),
    savePreset: vi.fn(),
    deletePreset: vi.fn(),
  }),
}));

vi.mock('../../hooks/useSortedRows', () => ({
  default: (data) => ({
    sorted: data || [],
    sortState: { key: null, direction: 'asc' },
    onSort: vi.fn(),
  }),
}));

vi.mock('../LitigationForm', () => ({
  default: ({ show }) => show ? <div data-testid="litigation-form" /> : null,
}));

const mockCases = {
  data: [
    {
      id: 1,
      litigation_number: 'LIT-2025-001',
      company_name: 'Acme Corp',
      petitioner: 'John Doe',
      respondent: 'Jane Smith',
      stage: 'filing',
      next_hearing_date: '2025-08-15',
      status: 'active',
      balance: 50000,
      cnr_number: 'CNR001',
    },
    {
      id: 2,
      litigation_number: 'LIT-2025-002',
      company_name: 'Globex Inc',
      petitioner: 'Bob Wilson',
      respondent: 'Alice Brown',
      stage: 'notice',
      next_hearing_date: '2025-09-01',
      status: 'pending',
      balance: 0,
      cnr_number: 'CNR002',
    },
  ],
  meta: { current_page: 1, last_page: 1, total: 2 },
  kpis: {
    total: 2,
    active: 1,
    pending: 1,
    disposed: 0,
    settled: 0,
    dismissed: 0,
    withdrawn: 0,
  },
};

describe('LitigationList - Delete', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    fetchCases.mockResolvedValue(mockCases);
  });

  it('renders the list page with cases', async () => {
    render(<LitigationList />);
    await waitFor(() => {
      expect(screen.getByText('LIT-2025-001')).toBeInTheDocument();
    });
    expect(screen.getByText('LIT-2025-002')).toBeInTheDocument();
  });

  it('renders KPI cards with counts', async () => {
    render(<LitigationList />);
    await waitFor(() => {
      expect(screen.getByText('Total Cases')).toBeInTheDocument();
    });
    expect(screen.getAllByText('Active').length).toBeGreaterThanOrEqual(1);
  });

  it('shows delete button for each case row', async () => {
    render(<LitigationList />);
    await waitFor(() => {
      expect(screen.getByText('LIT-2025-001')).toBeInTheDocument();
    });
    const deleteButtons = screen.getAllByTitle('Delete');
    expect(deleteButtons.length).toBe(2);
  });

  it('shows SweetAlert confirmation when delete is clicked', async () => {
    const user = userEvent.setup();
    Swal.fire.mockResolvedValue({ isConfirmed: false });

    render(<LitigationList />);
    await waitFor(() => {
      expect(screen.getByText('LIT-2025-001')).toBeInTheDocument();
    });

    const deleteButtons = screen.getAllByTitle('Delete');
    await user.click(deleteButtons[0]);

    expect(Swal.fire).toHaveBeenCalledWith(
      expect.objectContaining({
        icon: 'warning',
        title: 'Delete this case?',
        showCancelButton: true,
      })
    );
  });

  it('does not call deleteCase when user cancels', async () => {
    const user = userEvent.setup();
    Swal.fire.mockResolvedValue({ isConfirmed: false });

    render(<LitigationList />);
    await waitFor(() => {
      expect(screen.getByText('LIT-2025-001')).toBeInTheDocument();
    });

    const deleteButtons = screen.getAllByTitle('Delete');
    await user.click(deleteButtons[0]);

    expect(deleteCase).not.toHaveBeenCalled();
  });

  it('calls deleteCase when user confirms deletion', async () => {
    const user = userEvent.setup();
    Swal.fire
      .mockResolvedValueOnce({ isConfirmed: true })
      .mockResolvedValueOnce({ isConfirmed: false });

    render(<LitigationList />);
    await waitFor(() => {
      expect(screen.getByText('LIT-2025-001')).toBeInTheDocument();
    });

    const deleteButtons = screen.getAllByTitle('Delete');
    await user.click(deleteButtons[0]);

    await waitFor(() => {
      expect(deleteCase).toHaveBeenCalledWith(1);
    });
  });

  it('reloads data after successful deletion', async () => {
    const user = userEvent.setup();
    Swal.fire
      .mockResolvedValueOnce({ isConfirmed: true })
      .mockResolvedValueOnce({ isConfirmed: false });

    render(<LitigationList />);
    await waitFor(() => {
      expect(screen.getByText('LIT-2025-001')).toBeInTheDocument();
    });

    const deleteButtons = screen.getAllByTitle('Delete');
    await user.click(deleteButtons[0]);

    await waitFor(() => {
      expect(fetchCases).toHaveBeenCalledTimes(2);
    });
  });

  it('shows success alert after deletion', async () => {
    const user = userEvent.setup();
    Swal.fire
      .mockResolvedValueOnce({ isConfirmed: true })
      .mockResolvedValueOnce({ isConfirmed: false });

    render(<LitigationList />);
    await waitFor(() => {
      expect(screen.getByText('LIT-2025-001')).toBeInTheDocument();
    });

    const deleteButtons = screen.getAllByTitle('Delete');
    await user.click(deleteButtons[0]);

    await waitFor(() => {
      expect(Swal.fire).toHaveBeenCalledWith(
        expect.objectContaining({
          icon: 'success',
          title: 'Deleted',
        })
      );
    });
  });

  it('shows error alert when deletion fails', async () => {
    const user = userEvent.setup();
    const error = {
      response: { status: 500, data: { message: 'Cannot delete case with active hearings' } },
    };
    deleteCase.mockRejectedValue(error);
    Swal.fire.mockResolvedValue({ isConfirmed: true });

    render(<LitigationList />);
    await waitFor(() => {
      expect(screen.getByText('LIT-2025-001')).toBeInTheDocument();
    });

    const deleteButtons = screen.getAllByTitle('Delete');
    await user.click(deleteButtons[0]);

    await waitFor(() => {
      expect(Swal.fire).toHaveBeenCalledWith(
        expect.objectContaining({
          icon: 'error',
          title: 'Cannot delete',
          text: 'Cannot delete case with active hearings',
        })
      );
    });
  });

  it('shows generic error message when deletion fails without response message', async () => {
    const user = userEvent.setup();
    deleteCase.mockRejectedValue(new Error('Network error'));
    Swal.fire.mockResolvedValue({ isConfirmed: true });

    render(<LitigationList />);
    await waitFor(() => {
      expect(screen.getByText('LIT-2025-001')).toBeInTheDocument();
    });

    const deleteButtons = screen.getAllByTitle('Delete');
    await user.click(deleteButtons[0]);

    await waitFor(() => {
      expect(Swal.fire).toHaveBeenCalledWith(
        expect.objectContaining({
          icon: 'error',
          title: 'Cannot delete',
          text: 'Delete failed.',
        })
      );
    });
  });

  it('opens Create modal when Add Litigation is clicked', async () => {
    const user = userEvent.setup();
    render(<LitigationList />);
    await waitFor(() => {
      expect(screen.getByText('LIT-2025-001')).toBeInTheDocument();
    });

    const addButton = screen.getByText('Add Litigation');
    await user.click(addButton);

    await waitFor(() => {
      expect(screen.getByTestId('litigation-form')).toBeInTheDocument();
    });
  });

  it('loads loading state initially', () => {
    fetchCases.mockReturnValue(new Promise(() => {}));
    render(<LitigationList />);
    expect(screen.getByText('Loading...')).toBeInTheDocument();
  });

  it('shows error state when fetch fails', async () => {
    fetchCases.mockRejectedValue({ response: { data: { message: 'Server error' } } });
    render(<LitigationList />);
    await waitFor(() => {
      expect(screen.getByText('Server error')).toBeInTheDocument();
    });
  });
});
