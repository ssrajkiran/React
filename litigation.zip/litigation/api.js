import api from '../../api/axios';

// ── Companies for dropdown ──────────────────────────────────────────
export async function fetchCompanies() {
  const res = await api.get('/litigation/companies');
  return res.data;
}

// ── Cases ────────────────────────────────────────────────────────────
export async function fetchCases(params = {}) {
  const query = new URLSearchParams();
  Object.entries(params).forEach(([key, value]) => {
    if (value !== '' && value !== undefined && value !== null) {
      query.set(key, value);
    }
  });
  const res = await api.get(`/litigation?${query.toString()}`);
  return res.data;
}

export async function fetchCase(id) {
  const res = await api.get(`/litigation/${id}`);
  return res.data;
}

export async function createCase(formData) {
  const res = await api.post('/litigation', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
  return res.data;
}

export async function updateCase(id, formData) {
  const res = await api.put(`/litigation/${id}`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
  return res.data;
}

export async function deleteCase(id) {
  const res = await api.delete(`/litigation/${id}`);
  return res.data;
}

// ── Documents ────────────────────────────────────────────────────────
export async function uploadDocuments(caseId, files) {
  const formData = new FormData();
  files.forEach((file) => formData.append('documents', file));
  const res = await api.post(`/litigation/${caseId}/documents`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
  return res.data;
}

export function getDocumentViewUrl(caseId, docId) {
  return `/api/litigation/${caseId}/documents/${docId}/view`;
}

export function getDocumentDownloadUrl(caseId, docId) {
  return `/api/litigation/${caseId}/documents/${docId}/download`;
}

export async function deleteDocument(caseId, docId) {
  const res = await api.delete(`/litigation/${caseId}/documents/${docId}`);
  return res.data;
}

// ── Fetch document as blob (auth-aware) ───────────────────────────────
export async function fetchDocumentBlob(caseId, docId) {
  const res = await api.get(`/litigation/${caseId}/documents/${docId}/view`, {
    responseType: 'blob',
  });
  return res.data;
}

// ── Export ────────────────────────────────────────────────────────────
export function getExportUrl(params = {}) {
  const query = new URLSearchParams();
  Object.entries(params).forEach(([key, value]) => {
    if (value !== '' && value !== undefined && value !== null) {
      query.set(key, value);
    }
  });
  return `/api/litigation/export?${query.toString()}`;
}

