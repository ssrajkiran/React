// ── Case Types (39 values) ─────────────────────────────────────────────
export const CASE_TYPES = {
  AP: 'AP – Approval Petition',
  AS: 'AS – Appeal Suit',
  C: 'C – Complaint Petition',
  CC: 'CC – Calendar Case',
  CMA: 'CMA – Civil Miscellaneous Appeal',
  COS: 'COS – Commercial Original Suit',
  CP: 'CP – Claim Petition',
  CRLA: 'CRLA – Criminal Appeal',
  CRLMP: 'CRLMP – Criminal Miscellaneous Petition',
  CRLR: 'CRLR – Criminal Revision Petition',
  CRP: 'CRP – Civil Revision Petition',
  'Dist. Application': 'Dist. Application – Distress Application',
  DVC: 'DVC – Domestic Violence Case',
  EOCC: 'EOCC – Economic Offence Case',
  EP: 'EP – Execution Petition',
  IP: 'IP – Insolvency Petition',
  JC: 'JC – Juvenile Case',
  MC: 'MC – Maintenance Case',
  MCOP: 'MCOP – Motor Accidents Claim Original Petition',
  MJC: 'MJC – Miscellaneous Judicial Case',
  MTA: 'MTA – Municipal Taxation Appeal / Corporation Taxation Appeal',
  'NT Application': 'NT Application – New Trial Application',
  OA: 'OA – Original Application',
  OP: 'OP – Original Petition',
  OS: 'OS – Original Suit',
  PRC: 'PRC – Preliminary Register Case',
  PWA: 'PWA – Payment Wages Appeal',
  RC: 'RC – Reference Case',
  RCA: 'RCA – Rent Control Appeal',
  RCS: 'RCS – Referred Charge Sheet',
  RLTA: 'RLTA – Regulation of Rights and Responsibilities of Landlord and Tenant Appeals',
  RLTOP: 'RLTOP – Regulation of Rights and Responsibilities of Landlord and Tenant Original Petition',
  RP: 'RP – Review Petition',
  RTA: 'RTA – Rent Tribunal Appeal',
  SA: 'SA – Second Appeal',
  SC: 'SC – Sessions Case',
  SCC: 'SCC – Small Cause Suit',
  SOA: 'SOA – Standing Order Appeal',
  SPLCC: 'SPLCC – Special Calendar Case',
  'SPL.SC': 'SPL.SC – Special Sessions Case',
  STC: 'STC – Small Cause Calendar Case / Summary Trial Case',
};

export const CASE_TYPE_OPTIONS = Object.entries(CASE_TYPES).map(([value, label]) => ({ value, label }));

// ── Stages (9 values) ─────────────────────────────────────────────────
export const STAGE_LABELS = {
  filing: 'Filing',
  notice: 'Notice',
  written_statement: 'Written Statement',
  evidence: 'Evidence',
  arguments: 'Arguments',
  judgment: 'Judgment',
  appeal: 'Appeal',
  execution: 'Execution',
  disposed: 'Disposed',
};

export const STAGE_OPTIONS = Object.entries(STAGE_LABELS).map(([value, label]) => ({ value, label }));

// ── Statuses (6 values) ───────────────────────────────────────────────
export const STATUS_OPTIONS = [
  { value: 'active', label: 'Active' },
  { value: 'pending', label: 'Pending Hearing' },
  { value: 'disposed', label: 'Disposed' },
  { value: 'settled', label: 'Settled' },
  { value: 'dismissed', label: 'Dismissed' },
  { value: 'withdrawn', label: 'Withdrawn' },
];

export const STATUS_BADGE_CLASSES = {
  active: 'bg-amber-50 text-amber-600',
  pending: 'bg-blue-50 text-blue-600',
  disposed: 'bg-green-50 text-green-600',
  settled: 'bg-purple-50 text-purple-600',
  dismissed: 'bg-red-50 text-red-600',
  withdrawn: 'bg-gray-100 text-gray-500',
};

// ── File Icons ────────────────────────────────────────────────────────
export const FILE_ICON_MAP = {
  'application/pdf': { icon: 'fa-file-pdf', bg: '#FEF2F2', color: '#EF4444' },
  'image/jpeg': { icon: 'fa-file-image', bg: '#EFF6FF', color: '#2563EB' },
  'image/jpg': { icon: 'fa-file-image', bg: '#EFF6FF', color: '#2563EB' },
  'image/png': { icon: 'fa-file-image', bg: '#EFF6FF', color: '#2563EB' },
  'application/msword': { icon: 'fa-file-word', bg: '#F0FDF4', color: '#16A34A' },
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document': { icon: 'fa-file-word', bg: '#F0FDF4', color: '#16A34A' },
};

export const DEFAULT_FILE_ICON = { icon: 'fa-file', bg: '#F5F3FF', color: '#8B5CF6' };

// ── Table Config ──────────────────────────────────────────────────────
export const TABLE_COLUMNS = [
  { key: 'id', label: '#', sortable: true, width: 60, filterable: false },
  { key: 'cnr_number', label: 'CNR No', sortable: true, filterable: true, filterType: 'text' },
  { key: 'company', label: 'Company', sortable: true, filterable: true, filterType: 'text' },
  { key: 'litigation_number', label: 'Litigation No', sortable: true, filterable: true, filterType: 'text' },
  { key: 'petitioner', label: 'Petitioner', sortable: true, filterable: true, filterType: 'text' },
  { key: 'respondent', label: 'Respondent', sortable: true, filterable: true, filterType: 'text' },
  { key: 'stage', label: 'Stage', sortable: true, filterable: true, filterType: 'select', options: STAGE_OPTIONS },
  { key: 'next_hearing_date', label: 'Next Hearing', sortable: true, filterable: true, filterType: 'date' },
  { key: 'status', label: 'Status', sortable: true, filterable: true, filterType: 'select', options: STATUS_OPTIONS },
  { key: 'balance', label: 'Balance', sortable: true, filterable: false },
  { key: 'actions', label: 'Actions', sortable: false, filterable: false },
];

export const COLUMN_FILTER_KEYS = {
  cnr_number: 'cnrFilter',
  company: 'companyFilter',
  litigation_number: 'litNumberFilter',
  petitioner: 'petitionerFilter',
  respondent: 'respondentFilter',
  stage: 'stageFilter',
  next_hearing_date: 'hearingDateFilter',
  status: 'statusFilter',
};

export const COLUMNS_VISIBILITY_KEY = 'vhris_lr_hidden_cols';

// ── Permissions ──────────────────────────────────────────────────────
export const PERMISSION_SLUG = 'litigation-register';

// ── Allowed File Types ───────────────────────────────────────────────
export const ALLOWED_FILE_TYPES = '.pdf,.jpg,.jpeg,.png,.doc,.docx';
export const ALLOWED_MIME_TYPES = [
  'application/pdf',
  'image/jpeg',
  'image/png',
  'image/jpg',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
];
export const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10 MB

